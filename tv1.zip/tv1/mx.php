
<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>明星库 - MyTheme主题</title>
<meta name="keywords" content="MyTheme主题" />
<meta name="description" content="MyTheme主题" />
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="shortcut icon" href="https://mytheme-cdn.oss-cn-hangzhou.aliyuncs.com/v/favicon.ico" type="image/x-icon" />					
<link rel="stylesheet" href="/css/mytheme-font.css?v=2.3" type="text/css" />
<link rel="stylesheet" href="/css/mytheme-ui.css?v=2.3" type="text/css" />
<link rel="stylesheet" href="/css/mytheme-site.css?v=2.3" type="text/css" />
<link rel="stylesheet" href="/css/mytheme-color.css?v=2.3" type="text/css" name="default" />
<link rel="stylesheet" href="/css/mytheme-color.css?v=2.3" type="text/css" name="skin" disabled/>
<link rel="stylesheet" href="/css/mytheme-color1.css?v=2.3" type="text/css" name="skin" disabled/>
<link rel="stylesheet" href="/css/mytheme-color2.css?v=2.3" type="text/css" name="skin" disabled/>
<link rel="stylesheet" href="/css/mytheme-color3.css?v=2.3" type="text/css" name="skin" disabled/>
<link rel="stylesheet" href="/css/iconfont.css">
<script src="/js/iconfont.js"></script>
<script type="text/javascript" src="/js/jquery.min.js?v=3.3.1"></script>
<script type="text/javascript" src="/js/layer.js?v3.1.1"></script>
<script type="text/javascript" src="/js/mytheme-site.js?v=1.0.0"></script>
<script type="text/javascript" src="/js/mytheme-ui.js?v=1.0.0"></script>
<script type="text/javascript" src="/js/mytheme-cms.js?v=1.1.0"></script>
<style type="text/css">body{font-family:"Microsoft YaHei", "微软雅黑", "STHeiti", "WenQuanYi Micro Hei", SimSun, sans-serif;}[class*=col-],.myui-content__list li,.myui-vodlist__media.col li{ padding: 10px}.btn{ border-radius: 5px;}.myui-vodlist__thumb{ border-radius:5px; padding-top:150%; background: url(/template/mytheme/statics/img/load.png) no-repeat;}.myui-vodlist__thumb.square{ padding-top: 100%; background: url(/template/mytheme/statics/img/load_f.png) no-repeat;}.myui-vodlist__thumb.wide{ padding-top: 60%; background: url(/template/mytheme/statics/img/load_w.png) no-repeat;}.myui-vodlist__thumb.actor{ padding-top: 140%;}.flickity-prev-next-button.previous{ left: 10px;}.flickity-prev-next-button.next{ right: 10px;}.myui-sidebar{ padding: 0 0 0 20px;}.myui-panel{ margin-bottom: 20px; border-radius: 5px;}.myui-panel-mb{ margin-bottom: 20px;}.myui-player__item .fixed{ width: 500px;}.myui-vodlist__text li a,.myui-vodlist__media li{ padding: 10px 0;}.myui-screen__list{ padding: 10px 10px 0;}.myui-screen__list li{ margin-bottom: 10px; margin-right: 10px;}.myui-page{ padding: 0 10px;}.myui-extra{ right: 20px; bottom: 30px;}@media (min-width: 1200px){.container{ max-width: 1920px;}.container{ padding-left: 120px;  padding-right: 120px;}.container.min{ width: 1200px; padding: 0;}}@media (max-width: 767px){body,body.active{ padding-bottom: 50px;}[class*=col-],.myui-panel,.myui-content__list li{ padding: 5px}.flickity-prev-next-button.previous{ left: 5px;}.flickity-prev-next-button.next{ right: 5px;}.myui-vodlist__text li a,.myui-vodlist__media li{ padding: 10px 0;}.myui-screen__list{ padding: 10px 5px 0;}.myui-screen__list li{ margin-bottom: 5px; margin-right: 5px;}.myui-extra{ right: 20px; bottom: 80px;}.myui-page{ padding: 0 5px;}}.myui-topbg{ position: absolute; top: 0; left: 0; right: 0; width: 100%; }</style>
<!--[if lt IE 9]>
<script src="https://cdn.ceshifile.org/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.ceshifile.org/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->


</head>
<body>
<header class="myui-header__top clearfix" id="header-top">
	<div class="container">	
		<div class="row">
			<div class="myui-header_bd clearfix">					
			    <div class="myui-header__logo">			    	
					<a class="logo" href="/">
						<img class="img-responsive hidden-xs" src="/template/mytheme/statics/img/logo.png"/>
						<img class="img-responsive visible-xs" src="/template/mytheme/statics/img/logo_min.png"/>
					</a>					
				</div>
				<ul class="myui-header__menu nav-menu">
					<li class=" hidden-sm hidden-xs"><a href="/">首页</a></li>
					                    <li class=" hidden-sm hidden-xs"><a href="/index.php/vodtype/dianying.html">电影</a></li>
                                        <li class=" hidden-sm hidden-xs"><a href="/index.php/vodtype/lianxuju.html">连续剧</a></li>
                                        <li class=" hidden-sm hidden-xs"><a href="/index.php/vodtype/zongyi.html">综艺</a></li>
                                        <li class=" hidden-sm hidden-xs"><a href="/index.php/vodtype/dongman.html">动漫</a></li>
                    <li class=" hidden-md hidden-sm hidden-xs"><a href="/index.php/topic">专题</a></li><li class="active hidden-md hidden-sm hidden-xs"><a href="/index.php/actor">明星</a></li><li class=" hidden-md hidden-sm hidden-xs"><a href="/template/mytheme/admin/">后台</a></li>					<li class="dropdown-hover">
						<a href="javascript:;">频道 <i class="fa fa-angle-down"></i></a>
						<div class="dropdown-box bottom fadeInDown clearfix">
							<ul class="item nav-list clearfix">
								<li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/">首页</a></li>
											                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/dianying.html">电影</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/lianxuju.html">连续剧</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/zongyi.html">综艺</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/dongman.html">动漫</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/fuli.html">福利</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/arttype/zixun.html">资讯</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/dongzuopian.html">动作片</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/xijupian.html">喜剧片</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/aiqingpian.html">爱情片</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/kehuanpian.html">科幻片</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/kongbupian.html">恐怖片</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/juqingpian.html">剧情片</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/zhanzhengpian.html">战争片</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/guochanju.html">国产剧</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/gangtaiju.html">港台剧</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/rihanju.html">日韩剧</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/vodtype/oumeiju.html">欧美剧</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/arttype/yingshizixun.html">影视资讯</a></li>
			                    			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a class="btn btn-sm btn-block btn-default" href="/index.php/arttype/jinritoutiao.html">今日头条</a></li>
			                    <li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a  class="btn btn-sm btn-block btn-default" href="/index.php/topic">专题</a></li><li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a  class="btn btn-sm btn-block btn-default" href="/index.php/actor">明星</a></li><li class="col-lg-5 col-md-5 col-sm-5 col-xs-3"><a  class="btn btn-sm btn-block btn-default" href="/template/mytheme/admin/">后台</a></li>							</ul>
						</div>
					</li>
									</ul>
				<script type="text/javascript" src="/template/mytheme/statics/js/jquery.autocomplete.js"></script>				<div class="myui-header__search search-box"> 
										<a class="search-select dropdown-hover" href="javascript:;">
						<span class="text">视频</span> <i class="fa fa-caret-down"></i>
						<div class="dropdown-box bottom fadeInDown">
							<ul class="item">
								<li class="vod" data-action="/index.php/vodsearch/-------------.html">视频</li>
								<li class="news" data-action="/index.php/artsearch/-------.html">资讯</li><li class="actor" data-action="/index.php/actor/search.html">明星</li>							</ul>
						</div>
					</a>
					
								        <form id="search" name="search" method="get" action="/index.php/vodsearch/-------------.html" onSubmit="return qrsearch();">
    					<input type="text" id="wd" name="wd" class="search_wd form-control" value="" placeholder="我们都要好好的" autocomplete="off" style=" padding-left: 72px; "/>
						<button class="submit search_submit" id="searchbutton" type="submit" name="submit"><i class="fa fa-search"></i></button>							
					</form>
					<a class="search-close visible-xs" href="javascript:;"><i class="fa fa-close"></i></a>
										<div class="search-dropdown-hot dropdown-box bottom fadeInDown">
						<div class="item">
							<p class="text-muted">
								热门搜索
							</p>
														<p><a class="text-333" href="/index.php/vodsearch/%E7%A5%9E%E9%9B%95%E4%BE%A0%E4%BE%A3%5B%E5%88%98%E4%BA%A6%E8%8F%B2%E7%89%88%5D-------------.html" title=""><span class="badge badge-first">1</span> 神雕侠侣[刘亦菲版]</a></p>
														<p><a class="text-333" href="/index.php/vodsearch/%E7%88%86%E6%AC%BE%E8%AF%9E%E7%94%9F-------------.html" title=""><span class="badge badge-second">2</span> 爆款诞生</a></p>
														<p><a class="text-333" href="/index.php/vodsearch/%E6%96%AF%E5%BE%B7%E5%93%A5%E5%B0%94%E6%91%A9-------------.html" title=""><span class="badge badge-third">3</span> 斯德哥尔摩</a></p>
														<p><a class="text-333" href="/index.php/vodsearch/%E9%AC%BC%E7%9C%A8%E7%9C%BC-------------.html" title=""><span class="badge">4</span> 鬼眨眼</a></p>
														<p><a class="text-333" href="/index.php/vodsearch/%E5%83%B5%E5%B0%B8%E7%88%86%E6%A3%9A%E8%AE%B0-------------.html" title=""><span class="badge">5</span> 僵尸爆棚记</a></p>
													</div>
					</div>
								    </div>
			    				<ul class="myui-header__user">	
					<li class="visible-xs">
						<a class="open-search" href="javascript:;"><i class="fa fa-search"></i></a>
					</li>
					
										<li class="dropdown-hover">
						<a href="javascript:;" title="播放记录"> <i class="fa fa-clock-o"></i></a>
						<div class="dropdown-box fadeInDown">
							<div class="item clearfix">					
								<p class="text-muted">
									<a class="text-red pull-right" href="javascript:;" onclick="MyTheme.Cookie.Del('history','您确定要清除记录吗？');">[清空]</a>
									播放记录 
								</p>
								<div class="history-list clearfix">
									<script type="text/javascript">
										var history_get = MyTheme.Cookie.Get("history");
										if(history_get){
										    var json=eval("("+history_get+")");
										    for(i=0;i<json.length;i++){
										        document.write("<p><a class='text-333' href='"+json[i].link+"' title='"+json[i].name+"'><span class='pull-right text-red'>"+json[i].part+"</span>"+json[i].name+"</a></p>");
										    }
										} else {
											document.write("<p style='padding: 80px 0; text-align: center'>您还没有看过影片哦</p>");
									    }
									</script>
								</div>
								
							</div>
						</div>	
					</li>
					<li><a href="/index.php/gbook" title="留言反馈"><i class="fa fa-commenting"></i></a></li>					<li class="menu dropdown-hover">
						<a href="javascript:;"><i class="fa fa-user"></i></a>
						<div class="dropdown-box fadeInDown">
							<ul class="item clearfix">		
								<li><a class="text-333" href="/index.php/user/index.html">会员中心</a></li>
								<li><a class="text-333" href="/index.php/user/favs.html">我的收藏</a></li>
								<li><a class="text-333" href="/index.php/user/plays.html">播放记录</a></li>
								<li><a class="text-333" href="/index.php/user/reward.html">我的分销</a></li>
								<li><a class="text-333" href="/index.php/user/logout.html">退出</a></li>
							</ul>
						</div>
					</li>
									</ul>
		  	</div>		
		</div>						    
	</div>
</header>
<div class="container">
	<div class="row">
		<div class="myui-panel myui-panel-bg clearfix">
	<div class="myui-panel-box clearfix">
		<div class="myui-panel_hd">
			<div class="myui-panel__head clearfix">
				<h3 class="title">
					荧屏巨星
				</h3>	
							</div>
		</div>
		<div class="myui-panel_bd">
			<ul class="myui-vodlist__bd clearfix">
								
				<li class="col-md-10 col-sm-4 col-xs-3">
				<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45442.html" title="杨幂" data-original="//imgwx3.2345.com/dypcimg/star/img/c/0/16/photo_192x262.jpg?1477534221"><span class="pic-text text-right">
		演员歌手制片人</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45442.html" title="杨幂">杨幂</a></h4>
	</div>										
</div>
				</li>
								
				<li class="col-md-10 col-sm-4 col-xs-3">
				<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45439.html" title="关晓彤" data-original="//imgwx3.2345.com/dypcimg/star/img/a/8/24330/photo_192x262.jpg?1509946884"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45439.html" title="关晓彤">关晓彤</a></h4>
	</div>										
</div>
				</li>
								
				<li class="col-md-10 col-sm-4 col-xs-3">
				<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45436.html" title="罗晋" data-original="//imgwx3.2345.com/dypcimg/star/img/d/0/1806/photo_192x262.jpg?1505374685"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45436.html" title="罗晋">罗晋</a></h4>
	</div>										
</div>
				</li>
								
				<li class="col-md-10 col-sm-4 col-xs-3">
				<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45406.html" title="刘涛" data-original="//imgwx2.2345.com/dianyingimg/star/img/8/0/147/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45406.html" title="刘涛">刘涛</a></h4>
	</div>										
</div>
				</li>
								
				<li class="col-md-10 col-sm-4 col-xs-3">
				<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45327.html" title="刘诗诗" data-original="//imgwx2.2345.com/dianyingimg/star/img/e/0/34/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45327.html" title="刘诗诗">刘诗诗</a></h4>
	</div>										
</div>
				</li>
								
				<li class="col-md-10 col-sm-4 col-xs-3">
				<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43242.html" title="周星驰" data-original="//imgwx1.2345.com/dianyingimg/star/img/a/0/99/photo_192x262.jpg"><span class="pic-text text-right">
		演员导演编剧监制制片人出品人企业家</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43242.html" title="周星驰">周星驰</a></h4>
	</div>										
</div>
				</li>
								
				<li class="col-md-10 col-sm-4 col-xs-3">
				<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43236.html" title="周润发" data-original="//imgwx1.2345.com/dypcimg/star/img/3/0/137/photo_192x262.jpg?1510305618"><span class="pic-text text-right">
		影视演员艺人明星</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43236.html" title="周润发">周润发</a></h4>
	</div>										
</div>
				</li>
								
				<li class="col-md-10 col-sm-4 col-xs-3">
				<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43239.html" title="成龙" data-original="//imgwx5.2345.com/dianyingimg/star/img/4/0/62/photo_192x262.jpg"><span class="pic-text text-right">
		电影演员导演歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43239.html" title="成龙">成龙</a></h4>
	</div>										
</div>
				</li>
								
				<li class="col-md-10 col-sm-4 col-xs-3 hidden-sm">
				<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43224.html" title="甄子丹" data-original="//imgwx3.2345.com/dianyingimg/star/img/f/0/149/photo_192x262.jpg"><span class="pic-text text-right">
		导演演员动作指导</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43224.html" title="甄子丹">甄子丹</a></h4>
	</div>										
</div>
				</li>
								
				<li class="col-md-10 col-sm-4 col-xs-3 hidden-xs hidden-sm">
				<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42641.html" title="赵又廷" data-original="//imgwx4.2345.com/dianyingimg/star/img/8/0/197/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42641.html" title="赵又廷">赵又廷</a></h4>
	</div>										
</div>
				</li>
							</ul>
		</div>	
		
	</div>						
</div>
<!-- 推荐 -->
				<div class="myui-layout clearfix">
						<div class="myui-layout-box col-md-2 col-xs-1">
				<div class="myui-panel active myui-panel-bg clearfix">	
					<div class="myui-panel-box clearfix">													
						<div class="myui-panel_hd">
							<div class="myui-panel__head clearfix">
								<h3 class="title">
									内地明星
								</h3>	
								<a class="more text-muted" href="/index.php/actorshow/--------.html">更多 <i class="fa fa-angle-right"></i></a>
							</div>																		
						</div>
						<div class="myui-panel_bd clearfix">																
							<ul class="myui-vodlist clearfix">
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45444.html" title="赵丽颖" data-original="//imgwx3.2345.com/dianyingimg/star/img/d/0/388/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45444.html" title="赵丽颖">赵丽颖</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45443.html" title="吴京" data-original="//imgwx4.2345.com/dypcimg/star/img/2/0/204/photo_192x262.jpg?1509950263"><span class="pic-text text-right">
		演员导演</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45443.html" title="吴京">吴京</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45442.html" title="杨幂" data-original="//imgwx3.2345.com/dypcimg/star/img/c/0/16/photo_192x262.jpg?1477534221"><span class="pic-text text-right">
		演员歌手制片人</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45442.html" title="杨幂">杨幂</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45441.html" title="杨紫" data-original="//imgwx3.2345.com/dypcimg/star/img/f/0/335/photo_192x262.jpg?1509947665"><span class="pic-text text-right">
		演员歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45441.html" title="杨紫">杨紫</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45440.html" title="郑爽" data-original="//imgwx3.2345.com/dianyingimg/star/img/c/0/13/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45440.html" title="郑爽">郑爽</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45439.html" title="关晓彤" data-original="//imgwx3.2345.com/dypcimg/star/img/a/8/24330/photo_192x262.jpg?1509946884"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45439.html" title="关晓彤">关晓彤</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45438.html" title="鹿晗" data-original="//imgwx5.2345.com/dianyingimg/star/img/3/8/26242/photo_192x262.jpg?1442471602"><span class="pic-text text-right">
		演员歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45438.html" title="鹿晗">鹿晗</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45437.html" title="黄渤" data-original="//imgwx3.2345.com/dianyingimg/star/img/4/0/821/photo_192x262.jpg"><span class="pic-text text-right">
		演员歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45437.html" title="黄渤">黄渤</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45436.html" title="罗晋" data-original="//imgwx3.2345.com/dypcimg/star/img/d/0/1806/photo_192x262.jpg?1505374685"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45436.html" title="罗晋">罗晋</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-xs hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-45435.html" title="范冰冰" data-original="//imgwx5.2345.com/dianyingimg/star/img/3/0/23/photo_192x262.jpg"><span class="pic-text text-right">
		演员歌手制片人</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-45435.html" title="范冰冰">范冰冰</a></h4>
	</div>										
</div>												
								</li>
																	
							</ul>
						</div>
					</div>
				</div>
			</div>
						<div class="myui-layout-box col-md-2 col-xs-1">
				<div class="myui-panel active myui-panel-bg clearfix">	
					<div class="myui-panel-box clearfix">													
						<div class="myui-panel_hd">
							<div class="myui-panel__head clearfix">
								<h3 class="title">
									香港明星
								</h3>	
								<a class="more text-muted" href="/index.php/actorshow/--------.html">更多 <i class="fa fa-angle-right"></i></a>
							</div>																		
						</div>
						<div class="myui-panel_bd clearfix">																
							<ul class="myui-vodlist clearfix">
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43242.html" title="周星驰" data-original="//imgwx1.2345.com/dianyingimg/star/img/a/0/99/photo_192x262.jpg"><span class="pic-text text-right">
		演员导演编剧监制制片人出品人企业家</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43242.html" title="周星驰">周星驰</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43239.html" title="成龙" data-original="//imgwx5.2345.com/dianyingimg/star/img/4/0/62/photo_192x262.jpg"><span class="pic-text text-right">
		电影演员导演歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43239.html" title="成龙">成龙</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43236.html" title="周润发" data-original="//imgwx1.2345.com/dypcimg/star/img/3/0/137/photo_192x262.jpg?1510305618"><span class="pic-text text-right">
		影视演员艺人明星</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43236.html" title="周润发">周润发</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43233.html" title="刘德华" data-original="//imgwx4.2345.com/dianyingimg/star/img/3/0/28/photo_192x262.jpg"><span class="pic-text text-right">
		演员歌手填词人制片人</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43233.html" title="刘德华">刘德华</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43230.html" title="陈键锋" data-original="//imgwx1.2345.com/dianyingimg/star/img/6/0/545/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43230.html" title="陈键锋">陈键锋</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43227.html" title="林正英" data-original="//imgwx2.2345.com/dypcimg/star/img/0/0/269/photo_192x262.jpg?1510301292"><span class="pic-text text-right">
		演员动作指导</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43227.html" title="林正英">林正英</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43225.html" title="佘诗曼" data-original="//imgwx4.2345.com/dianyingimg/star/img/b/0/174/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43225.html" title="佘诗曼">佘诗曼</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43224.html" title="甄子丹" data-original="//imgwx3.2345.com/dianyingimg/star/img/f/0/149/photo_192x262.jpg"><span class="pic-text text-right">
		导演演员动作指导</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43224.html" title="甄子丹">甄子丹</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43223.html" title="周柏豪" data-original="//imgwx5.2345.com/dianyingimg/star/img/7/0/2173/photo_192x262.jpg"><span class="pic-text text-right">
		歌手演员模特儿</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43223.html" title="周柏豪">周柏豪</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-xs hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-43222.html" title="叶璇" data-original="//imgwx5.2345.com/dianyingimg/star/img/f/0/324/photo_192x262.jpg"><span class="pic-text text-right">
		演员出品人制片人编剧</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-43222.html" title="叶璇">叶璇</a></h4>
	</div>										
</div>												
								</li>
																	
							</ul>
						</div>
					</div>
				</div>
			</div>
						<div class="myui-layout-box col-md-2 col-xs-1">
				<div class="myui-panel active myui-panel-bg clearfix">	
					<div class="myui-panel-box clearfix">													
						<div class="myui-panel_hd">
							<div class="myui-panel__head clearfix">
								<h3 class="title">
									韩国明星
								</h3>	
								<a class="more text-muted" href="/index.php/actorshow/--------.html">更多 <i class="fa fa-angle-right"></i></a>
							</div>																		
						</div>
						<div class="myui-panel_bd clearfix">																
							<ul class="myui-vodlist clearfix">
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41779.html" title="池昌旭" data-original="//imgwx1.2345.com/dianyingimg/star/img/9/8/26245/photo_192x262.jpg?1442474913"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41779.html" title="池昌旭">池昌旭</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41778.html" title="李钟硕" data-original="//imgwx3.2345.com/dianyingimg/star/img/9/8/25516/photo_192x262.jpg"><span class="pic-text text-right">
		演员模特主持人</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41778.html" title="李钟硕">李钟硕</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41777.html" title="秋瓷炫" data-original="//imgwx3.2345.com/dianyingimg/star/img/1/0/411/photo_192x262.jpg"><span class="pic-text text-right">
		影视演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41777.html" title="秋瓷炫">秋瓷炫</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41776.html" title="裴秀智" data-original="//imgwx5.2345.com/dianyingimg/star/img/0/7/22798/photo_192x262.jpg"><span class="pic-text text-right">
		歌手演员主持人模特</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41776.html" title="裴秀智">裴秀智</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41775.html" title="林允儿" data-original="//imgwx5.2345.com/dypcimg/star/img/8/8/26244/photo_192x262.jpg?1509703499"><span class="pic-text text-right">
		歌手演员主持人</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41775.html" title="林允儿">林允儿</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41774.html" title="崔智友" data-original="//imgwx3.2345.com/dianyingimg/star/img/7/0/419/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41774.html" title="崔智友">崔智友</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41773.html" title="李准基" data-original="//imgwx4.2345.com/dianyingimg/star/img/f/0/94/photo_192x262.jpg?1455602786"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41773.html" title="李准基">李准基</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41772.html" title="宋慧乔" data-original="//imgwx2.2345.com/dianyingimg/star/img/c/0/12/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41772.html" title="宋慧乔">宋慧乔</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41771.html" title="张赫" data-original="//imgwx2.2345.com/dianyingimg/star/img/0/0/888/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41771.html" title="张赫">张赫</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-xs hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41770.html" title="李多海" data-original="//imgwx2.2345.com/dianyingimg/star/img/9/7/22290/photo_192x262.jpg"><span class="pic-text text-right">
		演员模特主持人歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41770.html" title="李多海">李多海</a></h4>
	</div>										
</div>												
								</li>
																	
							</ul>
						</div>
					</div>
				</div>
			</div>
						<div class="myui-layout-box col-md-2 col-xs-1">
				<div class="myui-panel active myui-panel-bg clearfix">	
					<div class="myui-panel-box clearfix">													
						<div class="myui-panel_hd">
							<div class="myui-panel__head clearfix">
								<h3 class="title">
									台湾明星
								</h3>	
								<a class="more text-muted" href="/index.php/actorshow/--------.html">更多 <i class="fa fa-angle-right"></i></a>
							</div>																		
						</div>
						<div class="myui-panel_bd clearfix">																
							<ul class="myui-vodlist clearfix">
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42648.html" title="黄维德" data-original="//imgwx3.2345.com/dianyingimg/star/img/8/0/901/photo_192x262.jpg"><span class="pic-text text-right">
		演员歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42648.html" title="黄维德">黄维德</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42647.html" title="陈楚河" data-original="//imgwx5.2345.com/dianyingimg/star/img/9/0/698/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42647.html" title="陈楚河">陈楚河</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42645.html" title="焦恩俊" data-original="//imgwx2.2345.com/dianyingimg/star/img/d/0/1097/photo_192x262.jpg"><span class="pic-text text-right">
		演员歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42645.html" title="焦恩俊">焦恩俊</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42644.html" title="阮经天" data-original="//imgwx3.2345.com/dypcimg/star/img/b/0/193/photo_192x262.jpg?1504073953"><span class="pic-text text-right">
		演员模特</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42644.html" title="阮经天">阮经天</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42642.html" title="王祖贤" data-original="//imgwx5.2345.com/dianyingimg/star/img/a/0/171/photo_192x262.jpg"><span class="pic-text text-right">
		演员歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42642.html" title="王祖贤">王祖贤</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42641.html" title="赵又廷" data-original="//imgwx4.2345.com/dianyingimg/star/img/8/0/197/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42641.html" title="赵又廷">赵又廷</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42639.html" title="欧阳娜娜" data-original="//imgwx2.2345.com/dypcimg/star/img/f/8/26243/photo_192x262.jpg?1509703765"><span class="pic-text text-right">
		大提琴演奏家演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42639.html" title="欧阳娜娜">欧阳娜娜</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42637.html" title="林心如" data-original="//imgwx2.2345.com/dypcimg/star/img/1/0/33/photo_192x262.jpg?1509945930"><span class="pic-text text-right">
		演员歌手制片人</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42637.html" title="林心如">林心如</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42635.html" title="安以轩" data-original="//imgwx3.2345.com/dianyingimg/star/img/d/0/39/photo_192x262.jpg"><span class="pic-text text-right">
		演员歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42635.html" title="安以轩">安以轩</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-xs hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42634.html" title="苏有朋" data-original="//imgwx1.2345.com/dianyingimg/star/img/8/0/175/photo_192x262.jpg"><span class="pic-text text-right">
		演员歌手制片人导演</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42634.html" title="苏有朋">苏有朋</a></h4>
	</div>										
</div>												
								</li>
																	
							</ul>
						</div>
					</div>
				</div>
			</div>
						<div class="myui-layout-box col-md-2 col-xs-1">
				<div class="myui-panel active myui-panel-bg clearfix">	
					<div class="myui-panel-box clearfix">													
						<div class="myui-panel_hd">
							<div class="myui-panel__head clearfix">
								<h3 class="title">
									美国明星
								</h3>	
								<a class="more text-muted" href="/index.php/actorshow/--------.html">更多 <i class="fa fa-angle-right"></i></a>
							</div>																		
						</div>
						<div class="myui-panel_bd clearfix">																
							<ul class="myui-vodlist clearfix">
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41255.html" title="何润东" data-original="//imgwx2.2345.com/dypcimg/star/img/5/0/322/photo_192x262.jpg?1510306939"><span class="pic-text text-right">
		演员歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41255.html" title="何润东">何润东</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41252.html" title="李小龙" data-original="//imgwx3.2345.com/dypcimg/star/img/9/0/165/photo_192x262.jpg?1509950127"><span class="pic-text text-right">
		武术家演员导演编剧哲学家慈善家</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41252.html" title="李小龙">李小龙</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41250.html" title="吴建豪" data-original="//imgwx3.2345.com/dianyingimg/star/img/6/0/536/photo_192x262.jpg"><span class="pic-text text-right">
		歌手演员制作人设计师老板</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41250.html" title="吴建豪">吴建豪</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41248.html" title="李玟" data-original="//imgwx5.2345.com/dianyingimg/star/img/7/0/486/photo_192x262.jpg"><span class="pic-text text-right">
		歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41248.html" title="李玟">李玟</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41249.html" title="巨石强森" data-original="//imgwx2.2345.com/dianyingimg/star/img/c/1/3648/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41249.html" title="巨石强森">巨石强森</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41245.html" title="李美琪" data-original="//imgwx2.2345.com/dianyingimg/star/img/a/0/467/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41245.html" title="李美琪">李美琪</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41246.html" title="安雅" data-original="//imgwx2.2345.com/dypcimg/star/img/9/0/2365/photo_192x262.jpg?1458548019"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41246.html" title="安雅">安雅</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41247.html" title="吴彦祖" data-original="//imgwx1.2345.com/dianyingimg/star/img/e/0/205/photo_192x262.jpg"><span class="pic-text text-right">
		演员导演监制CEO</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41247.html" title="吴彦祖">吴彦祖</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41243.html" title="布鲁斯" data-original="//imgwx2.2345.com/dianyingimg/star/img/c/2/7308/photo_192x262.jpg"><span class="pic-text text-right">
		导演</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41243.html" title="布鲁斯">布鲁斯</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-xs hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-41244.html" title="王力宏" data-original="//imgwx2.2345.com/dianyingimg/star/img/2/0/115/photo_192x262.jpg"><span class="pic-text text-right">
		歌手音乐制作人演员导演</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-41244.html" title="王力宏">王力宏</a></h4>
	</div>										
</div>												
								</li>
																	
							</ul>
						</div>
					</div>
				</div>
			</div>
						<div class="myui-layout-box col-md-2 col-xs-1">
				<div class="myui-panel active myui-panel-bg clearfix">	
					<div class="myui-panel-box clearfix">													
						<div class="myui-panel_hd">
							<div class="myui-panel__head clearfix">
								<h3 class="title">
									日本明星
								</h3>	
								<a class="more text-muted" href="/index.php/actorshow/--------.html">更多 <i class="fa fa-angle-right"></i></a>
							</div>																		
						</div>
						<div class="myui-panel_bd clearfix">																
							<ul class="myui-vodlist clearfix">
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42293.html" title="入江纱绫" data-original="//imgwx2.2345.com/dianyingimg/star/img/b/0/2177/photo_192x262.jpg"><span class="pic-text text-right">
		模特演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42293.html" title="入江纱绫">入江纱绫</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42292.html" title="菅田将晖" data-original="//imgwx1.2345.com/dianyingimg/star/img/f/1/5259/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42292.html" title="菅田将晖">菅田将晖</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42291.html" title="金城武" data-original="//imgwx4.2345.com/dypcimg/star/img/5/0/514/photo_192x262.jpg?1513578598"><span class="pic-text text-right">
		演员歌手</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42291.html" title="金城武">金城武</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42289.html" title="神木隆之介" data-original="//imgwx4.2345.com/dypcimg/star/img/e/1/3421/photo_192x262.jpg?1512039253"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42289.html" title="神木隆之介">神木隆之介</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42287.html" title="涩谷天马" data-original="//imgwx3.2345.com/dianyingimg/star/img/e/0/2635/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42287.html" title="涩谷天马">涩谷天马</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42286.html" title="山崎敬一" data-original="//imgwx2.2345.com/dianyingimg/star/img/9/8/26007/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42286.html" title="山崎敬一">山崎敬一</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42284.html" title="宫崎骏" data-original="//imgwx2.2345.com/dianyingimg/star/img/7/0/1434/photo_192x262.jpg"><span class="pic-text text-right">
		动画导演编剧作家</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42284.html" title="宫崎骏">宫崎骏</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42283.html" title="苍井空" data-original="//imgwx5.2345.com/dypcimg/star/img/d/0/10/photo_192x262.jpg?1510303610"><span class="pic-text text-right">
		AV女优电视电影演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42283.html" title="苍井空">苍井空</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42282.html" title="伊藤步" data-original="//imgwx3.2345.com/dianyingimg/star/img/4/1/4106/photo_192x262.jpg"><span class="pic-text text-right">
		演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42282.html" title="伊藤步">伊藤步</a></h4>
	</div>										
</div>												
								</li>
												
								<li class="col-md-5 col-sm-4 col-xs-3 hidden-xs hidden-sm">
									<div class="myui-vodlist__box">
			<a class="myui-vodlist__thumb actor lazyload" href="/index.php/actordetail-42281.html" title="山下智久" data-original="//imgwx2.2345.com/dianyingimg/star/img/6/0/525/photo_192x262.jpg"><span class="pic-text text-right">
		歌手演员</span>
	</a>									
	<div class="myui-vodlist__detail">
		<h4 class="title text-overflow text-center"><a href="/index.php/actordetail-42281.html" title="山下智久">山下智久</a></h4>
	</div>										
</div>												
								</li>
																	
							</ul>
						</div>
					</div>
				</div>
			</div>
					</div>
			</div>
</div>
<div class="myui-foot clearfix">
	<div class="container min">
		<div class="row">
			<div class="col-pd text-center">
				<p>本站所有视频和图片均来自互联网收集而来，版权归原创者所有，本网站只提供web页面服务，并不提供资源存储，也不参与录制、上传<br>若本站收录的节目无意侵犯了贵司版权，请发邮件至123456@qq.com （我们会在3个工作日内删除侵权内容，谢谢。）</p>	
				<p class="hidden-xs">
					<a target="_blank" href="/index.php/map.html">网站地图</a><span class="split-line"></span>
					<a target="_blank" href="/index.php/rss.xml">RSS订阅</a><span class="split-line"></span>
					<a target="_blank" href="/index.php/rss/baidu.xml">百度蜘蛛</a><span class="split-line"></span>
					<a target="_blank" href="/index.php/rss/google.xml">谷歌地图</a><span class="split-line"></span>
					<a target="_blank" href="/index.php/rss/bing.xml">必应地图</a><span class="split-line"></span>
					<a target="_blank" href="/index.php/rss/so.xml">360地图</a><span class="split-line"></span>
					<a target="_blank" href="/index.php/rss/sogou.xml">搜狗地图</a>
				</p>	
				<p class="margin-0">
					© 2019 MYTHEME.CN主题设计 京ICP备14039688号-6				</p>	
				<div class="tongji"></div>
			</div>
		</div>
	</div>
</div>

<div class="myui-nav__tabbar">
		<a class="item" href="/index.php/vod/type/id/1.html">
		<img class="icon-img" src="/template/mytheme/statics/icon/icon1.png"/><p class="title">电影</p>
		</a>
		<a class="item" href="/index.php/vod/type/id/2.html">
		<img class="icon-img" src="/template/mytheme/statics/icon/icon2.png"/><p class="title">剧集</p>
		</a>
		<a class="item" href="/index.php/vod/type/id/3.html">
		<img class="icon-img" src="/template/mytheme/statics/icon/icon3.png"/><p class="title">综艺</p>
		</a>
		<a class="item" href="/index.php/vod/type/id/4.html">
		<img class="icon-img" src="/template/mytheme/statics/icon/icon4.png"/><p class="title">动漫</p>
		</a>
		<a class="item" href="/index.php/topic">
		<img class="icon-img" src="/template/mytheme/statics/icon/icon5.png"/><p class="title">专题</p>
		</a>
		<a class="item" href="/index.php/actor">
		<img class="icon-img" src="/template/mytheme/statics/icon/icon6_on.png"/><p class="title">明星</p>
		</a>
	</div>
<ul class="myui-extra clearfix">
	<li>
		<a class="backtop" href="javascript:scroll(0,0)" title="返回顶部" style="display: none;"><i class="fa fa-angle-up"></i></a>
	</li>
		<li>
		<a class="btnskin" href="javascript:;" title="切换皮肤"><i class="fa fa-windows"></i></a>
	</li>
		<li class="visible-xs">
		<a class="open-share" href="javascript:;" title="分享给朋友"><i class="fa fa-share-alt"></i></a>
	</li>
		<li class="dropdown-hover hidden-xs">
		<a href="javascript:;" title="关注我们" onclick="MyTheme.Layer.Img('关注我们','/template/mytheme/statics/img/weixincode.png','扫一扫关注我们')"><i class="fa fa-wechat"></i></a>
		<div class="dropdown-box right fadeInDown clearfix">
			<div class="item text-center">
				<div class="qrcode-box">
					<img src="/template/mytheme/statics/img/weixincode.png" width="120" />
				</div>
				<p>扫一扫关注我们</p>
			</div>
		</div>
	</li>
	<li><a href="/index.php/gbook" title="留言反馈"><i class="fa fa-commenting"></i></a></li></ul>
<div class="noticetext hide"><div style="padding: 20px 30px;"><p class="content">这是一款带后台管理系统的多功能主题，具备500+主题功能设置，演示站数据仅供参考且文件加密，购买正版不加密无广告，提供永久更新服务，当前提示关闭后24小时内不再显示</p><p><a class="btn btn-block btn-warm" href="https://www.mytheme.cn/maccms/149.html">立即购买</a></p><p><a class="btn btn-block btn-info" href="http://149.demo.mytheme.cn/template/mytheme/admin/">登录主题管理系统</a></p></div></div><script type="text/javascript">
	MyTheme.Images.Qrcode.Init();MyTheme.Other.Skin();MyTheme.Other.Share();MyTheme.Layer.Popbody('allpop','弹窗公告','.noticetext',1,'320','400');</script>

<script type="text/javascript">   
	document.onkeydown=function(){
		var e = window.event||arguments[0];
					if(e.keyCode==123){
				alert('你知道的太多了！');
					return false;
			}
				if((e.ctrlKey)&&(e.shiftKey)&&(e.keyCode==73)){
			alert('你知道的太多了！');
			return false;
		}
		if((e.ctrlKey)&&(e.keyCode==85)){
			alert('你知道的太多了！');
			return false;
		}
		if((e.ctrlKey)&&(e.keyCode==83)){
		   alert('你知道的太多了！');
		   return false;
		}
			}
	</script>
</body>
</html>