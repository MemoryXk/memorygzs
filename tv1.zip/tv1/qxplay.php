<?php
include('sava/inc.php');
include('sava/shoufei.php');
//获取详情字段
$result = mysql_query('select * from yycms_vod where b_id = '.$_GET['play'].' ');
if (!$rowqx = mysql_fetch_array($result)) {
	die ('您访问的視頻不存在');
}
$qxk=explode("\r\n",$rowqx['b_url']);
$qxkurl = explode("$",$qxk[0]);

$qqsp=explode(',',$yycms_a_qqsp);
for($i=0;$i<count($qqsp);$i++)
{
if($rowqx['b_name']==$d_scontentt[$i]){
//提示错误值
alert_href('由于侵权,视频已经下架,谢谢!','/index.html');	
     }	
}
include('templets/'.$yycms_a_mb.'/qxplay.php');
?>