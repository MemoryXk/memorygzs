<?php
//echo $_data['a_tj'] = str_replace('"',"'",'<script type="text/javascript" src="https://s5.cnzz.com/z_stat.php?id=1277761044&web_id=1277761044"></script>');


echo $_data['a_tj'] =addslashes('<script type="text/javascript" src="https://s5.cnzz.com/z_stat.php?id=1277761044&web_id=1277761044"></script>');

echo date('Y-m-d h:i:s', time());;
?>

