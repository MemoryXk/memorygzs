<?php
include '../sava/conn.php';
include '../sava/function.php';
function  get($url,$timeout = 20) {  
    $user_agent = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36";  
    $curl = curl_init();                                        //初始化 curl
    curl_setopt($curl, CURLOPT_URL, $url);                      //要访问网页 URL 地址
	curl_setopt($curl, CURLOPT_USERAGENT,$user_agent);		   //模拟用户浏览器信息 
    curl_setopt($curl, CURLOPT_REFERER,$url) ;               //伪装网页来源 URL
    curl_setopt($curl, CURLOPT_AUTOREFERER, 1);                //当Location:重定向时，自动设置header中的Referer:信息                   
    curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);             //数据传输的最大允许时间 
    curl_setopt($curl, CURLOPT_HEADER, 0);                     //不返回 header 部分
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);            //返回字符串，而非直接输出到屏幕上
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION,1);             //跟踪爬取重定向页面
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, '0');        //不检查 SSL 证书来源
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, '0');        //不检查 证书中 SSL 加密算法是否存在
	curl_setopt($curl, CURLOPT_ENCODING, '');	          //解决网页乱码问题
    return curl_exec($curl);  
}
$curl = curl_init();   
$info=get("http://yycms.saonantv.com/hqqx.php");
$arr=json_decode($info, TRUE);
if($arr['code']==400){
die('<script type="text/javascript">alert("' . $arr['msg'] . '");</script>');
exit;
}
function ysfl($fenlei){
switch($fenlei){
    case '动作片';
	     $fenlei="6";//
         break;
    case '喜剧片';
         $fenlei="9";//
         break;
    case '爱情片';
         $fenlei="7";//
         break;
    case '科幻片';
         $fenlei="1";//
         break;
	case '恐怖片';
         $fenlei="2";//
         break;
	case '剧情片';
         $fenlei="5";//
         break;	 
	case '战争片';
         $fenlei="4";//
         break;
	case '动漫片';
         $fenlei="10";//
         break;	 
         default ;
         $fenlei="0";
         break;
}
return $fenlei;
}
//判断影片是否存在
function IsExist($name){
	$sql="select count(*) as num from yycms_vod where b_name ='{$name}'";
	$result = mysql_query($sql);
	$row=mysql_fetch_array($result);
	return $row['num']==0;
}
//修改影片地址
function UpdateVod($img,$url,$descs,$actor,$wd){
	$_data['b_tp'] = $img;
	$_data['b_jj'] = $descs;
	$_data['b_url'] = $url;
	$_data['b_zy'] = $actor;
	$sql = 'update yycms_vod set ' . arrtoupdate($_data) . ' where b_name = "' . $wd . '"';
	$res =  mysql_query($sql);	
	return $res;
}
//添加新影片
function AddVod($img,$url,$descs,$actor,$wd,$parent){
	$_data['b_name'] = $wd;
	$_data['b_tp'] = $img;
    $_data['b_tj'] = '1';//不想推荐首页显示请把0改1
	$_data['b_jj'] = $descs;
	$_data['b_jf'] = '0';
	$_data['b_hy'] = '0';
	$_data['b_url'] = $url;
	$_data['b_zy'] = $actor;
	$_data['b_time'] = date("Y-m-d h:i:s",time());
	$_data['b_fl'] = $parent;//分类
	$str = arrtoinsert($_data);
	$sql = 'insert into yycms_vod (' . $str[0] . ') values (' . $str[1] . ')';
	$res =  mysql_query($sql);	
	return $res;
}
foreach ($arr as $id => $newarr){
$url="";
foreach ($newarr['url'] as $dz) {
$url=$dz;
}	
	 if (IsExist($newarr['wd'])) {
		AddVod($newarr['imgs'],$url,$newarr['descs'],$newarr['actor'],$newarr['wd'],ysfl($newarr['fenlei']));
		echo $newarr['wd']."不存在执行添加<br>";
	}else{

		UpdateVod($newarr['imgs'],$url,$newarr['descs'],$newarr['actor'],$newarr['wd']);
		echo $newarr['wd']."存在执行修改<br>";
	}
}
?>