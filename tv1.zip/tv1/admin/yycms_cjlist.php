<?php 
include('head.php');
?>
</head>
<body class="childrenBody">
<div class="x-nav">
	<span class="layui-breadcrumb">
	  <a>视频采集</a>
	</span>
	<a class="layui-btn layui-btn-small refresh" href="javascript:location.replace(location.href);" title="刷新"><i class="iconfont icon-refresh" style="line-height:30px"></i></a>
</div>
<?php
include('../sava/inc.php');
?>
<form id="form1" enctype="multipart/form-data" method="GET" class="layui-form layui-form-pane layui-mt-10">

<div class="layui-form-item">
<div class="layui-inline">		
			<label class="layui-form-label">资源站</label>
			<div class="layui-input-inline">
				<span id='typeidct'>
				<select name='zd' style='width:240px'>


<?php
foreach($yycmszyjx as $k=>$v){
echo "<option value='$k'>资源站$k";	
}
?>
</select>
</span>
			</div>
		</div>	

			<div class="layui-inline">		
				<label class="layui-form-label">关键词</label>
				<div class="layui-input-inline">
					<input type="text" name="wd" value="" required="" lay-verify="required" placeholder="影片" class="layui-input">
				</div>
				<div class="layui-input-inline" style="width:80px">
				<button class="layui-btn" type="submit"><i class="layui-icon">&#xe615;</i></button>
			</div>
			<div class="layui-input-inline"><button type="button"  onclick="javascript:alert('<?php echo dirname($url);?>/hqqx.php 可宝塔定时访问这个链接.定时每天12点采集')"  class="layui-btn layui-btn-normal">获取最新入库</button></div>
			</div>	

		
</div>	
	
</form>

<div class="layui-form news_list"> 
    <table class="layui-table" lay-skin="line"> 
     <colgroup> 
          <col width="15%" />
          <col width="35%" />
          <col width="15%" />
          <col width="15%" />
      <col/> 
     </colgroup> 
     <thead> 
      <tr> 
      <th style="text-align:left;">id</th> 
       <th style="text-align:left;">名称</th> 
       <th style="text-align:left;">类型</th> 
       <th style="text-align:left;">时间</th> 
       <th style="text-align:left;">操作</th> 
      </tr> 
     </thead> 
     <tbody> 
      <tr> 
       <td colspan="6" style="padding:0;border:0;"> 
        <table style="width:100%;margin:0;border:0;" class="layui-table" lay-skin="line"> 
     <colgroup> 
          <col width="15%" />
          <col width="35%" />
          <col width="15%" />
          <col width="15%" />
      <col/> 
         <tbody>

<?php
if (isset($_GET['wd'])){
$hq1=yycmsget($yycmszyjx[$_GET['zd']].'?wd='.urlencode($_GET['wd']));
$data1=json_decode($hq1, TRUE);
$list1=$data1["data"];
foreach($list1 as $k=>$v){
?>
          <tr>
           <td align="left"><?php echo $k;?></td> 
           <td align="left"><?php echo $v['vod_name'];?></td> 
           <td align="left"><?php echo $v['list_name'];?></td> 
           <td align="left"><?php echo substr($v['vod_addtime'],0,10);?></td>      
           <td align="left"> <a href="yycms_addlist.php?zd=<?php echo $_GET['zd']; ?>&id=<?php echo $v['vod_id'];?>" class="layui-btn layui-btn-normal layui-btn-small"><i class="layui-icon"></i>采集</a></td> 
          </tr> 
<?php 
}
}
?>		  
         </tbody>
        </table> 
		</td> 
      </tr> 
     </tbody> 
    </table> 
  </div>
<?php 
include('footer.php');
?>
</body>
</html>