<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>优艺CMS影视管理系统</title>
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="format-detection" content="telephone=no">
<link rel="stylesheet" href="publics/layui/css/layui.css" media="all" />
<link rel="stylesheet" href="publics/iconfont/iconfont.css" media="all" />
<link rel="stylesheet" href="css/index.css" media="all" />
</head>
<body class="childrenBody">
<?php
include('../sava/conn.php');
include('../sava/function.php');
?>
<div class="panel_box row">
	<div class="panel col">
		<a target="main" href="yycms_dd.php">
			<div class="panel_icon layui-bg-blue">
				<i class="layui-icon">&#xe60a;</i>
			</div>
			<div class="panel_word">
				<span><?php $sql="SELECT COUNT(*) AS count FROM yycms_user_pay"; 
$result=mysql_fetch_array(mysql_query($sql)); 
$count=$result['count']; echo $count;?></span>
				<cite>支付订单</cite>
			</div>
		</a>
	</div>
	<div class="panel col">
		<a target="main" href="yycms_ly.php">
			<div class="panel_icon layui-bg-red">
				<i class="layui-icon">&#xe63a;</i>
			</div>
			<div class="panel_word userAll">
				<span><?php $sql="SELECT COUNT(*) AS count FROM yycms_ly"; 
$result=mysql_fetch_array(mysql_query($sql)); 
$count=$result['count']; echo $count;?></span>
				<cite>网站留言</cite>
			</div>
		</a>
	</div>
	<div class="panel col max_panel">
		<a target="main" href="yycms_user.php">
			<div class="panel_icon layui-bg-green">
				<i class="layui-icon">&#xe613;</i>
			</div>
			<div class="panel_word userAll">
				<span><?php $sql="SELECT COUNT(*) AS count FROM yycms_user"; 
$result=mysql_fetch_array(mysql_query($sql)); 
$count=$result['count']; echo $count;?></span>
				<cite>会员总数</cite>
			</div>
		</a>
	</div>
</div>
<div class="row">
	<div class="sysNotice col">
		<blockquote class="layui-elem-quote title">系统基本参数</blockquote>
		<table class="layui-table">
			<colgroup>
				<col width="150">
				<col>
			</colgroup>
			<tbody>
				<tr>
					<td>网站域名</td>
					<td><?php echo $_SERVER['HTTP_HOST'];?></td>
				</tr>
				<tr>
					<td>后台目录</td>
					<td><?php echo (__DIR__);?><a style="color:red">-安全起见请把后台默认admin文件夹修改其他名字</a></td>
				</tr>
				<tr>
					<td>操作系统</td>
					<td><?PHP echo PHP_OS; ?></td>
				</tr>
				<tr>
					<td>服务引擎</td>
					<td><?PHP echo $_SERVER ['SERVER_SOFTWARE']; ?></td>
				</tr>
				<tr>
					<td>环境版本</td>
					<td>PHP <?PHP echo PHP_VERSION; ?></td>
				</tr>
				<tr>
					<td>上传限制</td>
					<td><?PHP
echo get_cfg_var ("upload_max_filesize")?get_cfg_var ("upload_max_filesize"):"不允许上传附件";
?></td>
				</tr>

				<tr>
					<td>当前版本</td>
					<td><?php echo 优艺CMS_VERSION;?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div class="sysNotice col">
		<blockquote class="layui-elem-quote title">最新留言</blockquote>
		<table class="layui-table" lay-skin="line">
			<colgroup>
				<col>
				<col width="160">
			</colgroup>
			<tbody class="hot_news">
<?php $result = mysql_query('select * from yycms_ly order by ly_id desc LIMIT 0,13');
		while ($row = mysql_fetch_array($result)){
echo "<tr><td align='left'>".$row['ly_nr']."</a></td><td>".$row['ly_time']."</td></tr>";
}
?>			

</tbody>
		</table> 
	</div>
</div>
<script type="text/javascript" src="publics/layui/layui.js"></script>
<script type="text/javascript" src="js/index.js"></script>
</body>
</html>