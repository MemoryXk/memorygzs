<?php 
include('head.php');
?>
</head>
<body class="childrenBody">
<?php
include('../sava/inc.php');
error_reporting(0); //雨雨CMS作者QQ:201232694
if (isset($_GET['id'])){
$id=$_GET['id'];
$zy=$_GET['zd'];
switch($zy){
    case '0';
	     $zd= $yycmszyjx[0].'?vodids=';
         break;
    case '1';
     	 $zd= $yycmszyjx[1].'?vodids=';
         break;
    case '2';
    	 $zd= $yycmszyjx[2].'?vodids=';
         break;
         default ;
         break;
}
$data=json_decode(yycmsget($zd.$id),true);
$suArr1 = explode("$$$",$data['data'][0]['vod_url']);
				foreach($suArr1 as $a=>$b){  
				    $v = explode("\n",$b);
				    $d[] =$v; 
				}
				foreach($d as $k=>$v){    
				    foreach ($v as $k=>$cc){
				         $u = explode("$",$cc);
						if(strpos($u[1] ,'.m3u8')){
                 		$urls= $u[1];
						$dz.= $u[1];
                 		$title= $u[0];
                        $kk=$k+1;
						//$url.='<li><a href="'.str_replace("https","http",$urls).'" class="btn1" target="ajax" data-clipboard-text="" id="'.$kk.'" p_name="'.$title.'">'.$title.'</a></li>';
						$url.=''.$title.'$'.str_replace("https","http",$urls).'';
						}		
					}
				}				
}
?>
<div class="x-nav">
	<span class="layui-breadcrumb">
	  <a id="hqxz1" >视频添加</a>
	</span>
	<a class="layui-btn layui-btn-small refresh" href="javascript:location.replace(location.href);" title="刷新"><i class="iconfont icon-refresh" style="line-height:30px"></i></a>
</div>
<form id="sptj" enctype="multipart/form-data" method="post" class="layui-form layui-form-pane layui-mt-10">
<div class="layui-form-item">
					<label class="layui-form-label">视频名称</label>
					<div class="layui-input-block">
						<input type="text" name="yycms_b_name" required="" lay-verify="required" class="layui-input" value="<?php echo $data['data'][0]['vod_name'];?>">
					</div>
				</div>
<div class="layui-form-item">
					<label class="layui-form-label">视频图片</label>
					<div class="layui-input-block" id="typedir" style="width:30%;float:left;margin-left:0;">
						<input type="text" name="yycms_b_tp" id="yycms_b_tp" class="layui-input" value="<?php echo $data['data'][0]['vod_pic'];?>">
					</div>
					<div class="layui-input-inline"><button type="button" id="logo" class="layui-btn layui-btn-normal">选择</button></div>
				</div>	
<div class="layui-form-item">
					<label class="layui-form-label">主演</label>
					<div class="layui-input-block">
						<input type="text" name="yycms_b_zy" required="" lay-verify="required" class="layui-input" value="<?php echo '主演:'.$data['data'][0]['vod_actor'];?>">
					</div>
				</div>
	<div class="layui-form-item">
			<div class="layui-inline">		
				<label class="layui-form-label">积分</label>
				<div class="layui-input-inline">
					<input type="text" name="yycms_b_jf" value="0" class="layui-input">
				</div>
			</div>
			<div class="layui-inline">		
				<label class="layui-form-label">密码</label>
				<div class="layui-input-inline">
					<input type="text" name="yycms_b_pass" value="<?php echo $row['b_pass'];?>" class="layui-input">
				</div>
			</div>
<div class="layui-inline">		
			<label class="layui-form-label">分类</label>
			<div class="layui-input-inline">
				<span id='typeidct'>
<select name='yycms_b_fl' id='yycms_b_fl' style='width:240px'>
<option value='0'>请选择栏目...</option>
<?php echo channel_select_list(0,0,$_GET['cid'].$row['b_fl'],0);?>
</select>
</span>
			</div>
		</div>			
</div>	
<div class="layui-form-item">
<div class="layui-inline">		
			<label class="layui-form-label">会员</label>
			<div class="layui-input-inline">
				<span id='typeidct'>
				<select name='yycms_b_hy' style='width:240px'>
			<option value="0">全部</option>
<?php
							$result = mysql_query('select * from yycms_hy');
							while($row1 = mysql_fetch_array($result)){
						?>
						<option value="<?php echo $row1['ug_id']?>"><?php echo $row1['ug_name']?></option>
<?php
							}
						?>
</select>
</span>
			</div>
		</div>	
	<div class="layui-inline">		
				<label class="layui-form-label">推荐</label>
				<div class="layui-input-inline">
					<input type="radio" name="yycms_b_tj" title="是" value="1"> 
					<input type="radio" name="yycms_b_tj" title="否" value="0" checked="checked">				
				</div>
			</div>
</div>	
<div class="layui-form-item">
					<label class="layui-form-label">
					播放地址					</label>
					<div class="layui-input-block">
<textarea name='yycms_b_url' row='4' class='layui-textarea'><?php echo $url;?></textarea></div>
				</div>	
<div class="layui-form-item">
					<label class="layui-form-label">
					视频简介					</label>
					<div class="layui-input-block">
<textarea name='yycms_b_jj' row='4' class='layui-textarea'><?php echo $data['data'][0]['vod_content'];?></textarea></div>
				</div>	
	<div class="layui-form-item">
		<div class="layui-input-block">
		<input type="hidden" name="yycms" value="sptj">
			<button class="layui-btn"  onclick="sptj()">提交保存</button>
			<button type="reset" class="layui-btn layui-btn-danger">重置</button>
			<a class="layui-btn layui-btn-primary" href="javascript:;" onClick='history.go(-1);'>返回</a>
		</div>
	</div>
</form>

<script type='text/javascript'>
KindEditor.ready(function(K) {
	K.create('#s_copyright');
	var editor = K.editor();
	K('#logo').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#yycms_b_tp').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#yycms_b_tp').val(url);
				editor.hideDialog();
				}
			});
		});
	});
});  
</script>
<?php 
include('footer.php');
?>
</body>
</html>