<?
require_once('../sava/conn.php');
require_once('../sava/function.php');
error_reporting(0); 
header("Content-type:text/json");
//错误提示
function bc()
{
return json_encode(array('code' => '400', 'msg' => '权限不足'));
}
	function htdl()
	{
	$a_user_user = isset($_POST['user_user']) ? trim($_POST['user_user']) : '';
	$a_user_pass = isset($_POST['user_pass']) ? trim($_POST['user_pass']) : '';
	$sql = 'select * from yycms_pintai where a_user_user = "'.$a_user_user.'" and a_user_pass = "'.$a_user_pass.'"';
	$result = mysql_query($sql);
	if(!! $row = mysql_fetch_array($result)){
	setcookie('user_user',$row['a_user_user'],time()+3600*24);
	return json_encode(array('code' => '200', 'msg' => '登陆成功'));
	}else{
	return json_encode(array('code' => '400', 'msg' => '登陆失败-账号或密码错误'));
	}
	}
	function htxgmm()
	{
$_data['a_user_pass'] = $_POST['password2'];
$sql = 'update yycms_pintai set ' . arrtoupdate($_data) . ' where id = 1';
if (mysql_query($sql)) {
return json_encode(array('code' => '200', 'msg' => '修改成功'));
	} else {
	return json_encode(array('code' => '400', 'msg' => '修改失败1'));
	}}
	function httc()
	{
	setcookie('user_user','',time()-3600*24);
	return json_encode(array('code' => '200', 'msg' => '退出成功'));
	}
function xtxg1()
{
$_data['a_bt'] = $_POST['yycms_a_bt'];
$_data['a_name'] = $_POST['yycms_a_name'];
$_data['a_url'] = $_POST['yycms_a_url'];
$_data['a_keywords'] = $_POST['yycms_a_keywords'];
$_data['a_description'] = $_POST['yycms_a_description'];
$_data['a_bfqgg'] = $_POST['yycms_a_bfqgg'];
$_data['a_jzt'] = $_POST['yycms_a_jzt'];
$_data['a_hckg'] = $_POST['yycms_a_hckg'];
$_data['a_hcsj'] = $_POST['yycms_a_hcsj'];
$_data['a_logo'] = $_POST['yycms_a_logo'];
$_data['a_fhkg'] = $_POST['yycms_a_fhkg'];
$_data['a_mrjx'] = $_POST['yycms_a_mrjx'];
$_data['a_jxjk'] = $_POST['yycms_a_jxjk'];
$_data['a_zyjk'] = $_POST['yycms_a_zyjk'];
$_data['a_ggkg'] = '2';
$_data['a_gg'] = '2';
$_data['a_qqsp'] = $_POST['yycms_a_qqsp'];
$_data['a_bq'] = $_POST['yycms_a_bq'];
$_data['a_tj'] = addslashes($_POST['yycms_a_tj']);
$_data['a_dbdh'] = $_POST['yycms_a_dbdh'];
$_data['a_dylb'] = $_POST['yycms_a_dylb'];
$_data['a_dst'] = $_POST['yycms_a_dst'];
$_data['a_wximg'] = $_POST['yycms_a_wximg'];
$_data['a_sfkg'] = $_POST['yycms_a_sfkg'];
$_data['a_mb'] = $_POST['yycms_a_mb'];
$_data['a_kg1'] = $_POST['yycms_a_kg1'];
$sql = 'update yycms_pintai set ' . arrtoupdate($_data) . ' where id = '.$_POST['pintai'].'';
if (mysql_query($sql)) {
$file = '../sava/'.$_POST['pintai'].'.txt';	
unlink($file);	
$result = mysql_query('select * from yycms_pintai where id = '.$_POST['pintai'].'');
while ($record = mysql_fetch_array($result) )
{
$records[] = $record;
}
$OUTPUT = serialize($records);
$fp = fopen($file,"w"); // 以写权限的方式打开文件
fputs($fp, $OUTPUT);
	return json_encode(array('code' => '200', 'msg' => '修改成功'));
	} else {
	return json_encode(array('code' => '400', 'msg' => '修改失败'));
	}
	}
function xgseo()
{
$_data['s_bftitle'] = $_POST['yycms_bftitle'];
$_data['s_bfkeywords'] = $_POST['yycms_bfkeywords'];
$_data['s_bfdescription'] = $_POST['yycms_bfdescription'];
$sql = 'update yycms_pintai set ' . arrtoupdate($_data) . ' where id = '.$_POST['pintai'].'';
if (mysql_query($sql)) {
$file = '../sava/'.$_POST['pintai'].'.txt';	
unlink($file);	
$result = mysql_query('select * from yycms_pintai where id = '.$_POST['pintai'].'');
while ($record = mysql_fetch_array($result) )
{
$records[] = $record;
}
$OUTPUT = serialize($records);
$fp = fopen($file,"w"); // 以写权限的方式打开文件
fputs($fp, $OUTPUT);
	return json_encode(array('code' => '200', 'msg' => '修改成功'));
	} else {
	return json_encode(array('code' => '400', 'msg' => '修改失败'));
	}
	}	
function spxg()
{
$_data['b_name'] = $_POST['yycms_b_name'];
$_data['b_tp'] = $_POST['yycms_b_tp'];
$_data['b_zy'] = $_POST['yycms_b_zy'];
$_data['b_jf'] = $_POST['yycms_b_jf'];
$_data['b_pass'] = $_POST['yycms_b_pass'];
$_data['b_fl'] = $_POST['yycms_b_fl'];
$_data['b_hy'] = $_POST['yycms_b_hy'];
$_data['b_tj'] = $_POST['yycms_b_tj'];
$_data['b_url'] = $_POST['yycms_b_url'];
$_data['b_jj'] = $_POST['yycms_b_jj'];
$sql = 'update yycms_vod set ' . arrtoupdate($_data) . ' where b_id = '.$_POST['spid'].'';
if (mysql_query($sql)) {
	return json_encode(array('code' => '200', 'msg' => '修改成功'));
	} else {
	return json_encode(array('code' => '400', 'msg' => '修改失败'));
	}
	}
function sptj()
{
$_data['b_name'] = $_POST['yycms_b_name'];
$_data['b_tp'] = $_POST['yycms_b_tp'];
$_data['b_zy'] = $_POST['yycms_b_zy'];
$_data['b_jf'] = $_POST['yycms_b_jf'];
$_data['b_pass'] = $_POST['yycms_b_pass'];
$_data['b_fl'] = $_POST['yycms_b_fl'];
$_data['b_hy'] = $_POST['yycms_b_hy'];
$_data['b_tj'] = $_POST['yycms_b_tj'];
$_data['b_url'] = $_POST['yycms_b_url'];
$_data['b_jj'] = $_POST['yycms_b_jj'];
$_data['b_time'] = date('Y-m-d h:i:s', time());
$str = arrtoinsert($_data);
$sql = 'insert into yycms_vod (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
		return json_encode(array('code' => '200', 'msg' => '添加成功'));
	} else {
		return json_encode(array('code' => '400', 'msg' => '添加失败'));
	}
	}
function sclm()
{
	$sql = 'select * from yycms_vod_class where c_id = ' . $_POST['del'] . '';
	$result = mysql_query($sql);
	$row = mysql_fetch_array($result);
	mysql_query('delete from yycms_vod_class where c_id = ' . $_POST['del'] . '');
	mysql_query('delete from yycms_vod where d_class = ' . $_POST['del'] . '');
	return json_encode(array('code' => '200', 'msg' => '删除成功'));
	}
function tjlm()
{
	$_data['c_name'] = $_POST['c_name'];
	$str = arrtoinsert($_data);
	$sql = 'insert into yycms_vod_class (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
		return json_encode(array('code' => '200', 'msg' => '添加成功'));
	} else {
		return json_encode(array('code' => '400', 'msg' => '添加失败'));
	}
	}
function xglm()
{
	$_data['c_name'] = $_POST['c_name'];
	$sql = 'update yycms_vod_class set ' . arrtoupdate($_data) . ' where c_id = ' . $_POST['lmid'] . '';
	if (mysql_query($sql)) {
		return json_encode(array('code' => '200', 'msg' => '修改成功'));
	} else {
		return json_encode(array('code' => '400', 'msg' => '修改失败'));
	}
	}
function sfsz()
{
	//$_data['sf_kg'] = $_POST['yycms_sf_kg'];
	$_data['sf_cs'] = $_POST['yycms_sf_cs'];
	$_data['sf_bl'] = $_POST['yycms_sf_bl'];
	$_data['sf_zc'] = $_POST['yycms_sf_zc'];
	$_data['sf_gk'] = $_POST['yycms_sf_gk'];
	$_data['sf_km'] = $_POST['yycms_sf_km'];	
	$sql = 'update yycms_shoufei set ' . arrtoupdate($_data) . ' where sf_pingtai = ' . $_POST['pingtai'] . '';
	if (mysql_query($sql)) {
		return json_encode(array('code' => '200', 'msg' => '修改成功'));
	} else {
		return json_encode(array('code' => '400', 'msg' => '修改失败'));
	}
	}
function ggxg()
{
	$_data['gg_gg1'] = addslashes($_POST['yycms_gg_gg1']);
	$_data['gg_gg2'] = addslashes($_POST['yycms_gg_gg2']);
	$_data['gg_gg3'] = addslashes($_POST['yycms_gg_gg3']);
	$_data['gg_gg4'] = addslashes($_POST['yycms_gg_gg4']);
	$_data['gg_gg5'] = addslashes($_POST['yycms_gg_gg5']);
	$_data['gg_gg6'] = addslashes($_POST['yycms_gg_gg6']);
	$_data['gg_gg7'] = addslashes($_POST['yycms_gg_gg7']);
	$_data['gg_gg8'] = addslashes($_POST['yycms_gg_gg8']);
	$_data['gg_gg9'] = addslashes($_POST['yycms_gg_gg9']);
	$_data['gg_gg10'] = addslashes($_POST['yycms_gg_gg10']);
	$_data['gg_gg11'] = addslashes($_POST['yycms_gg_gg11']);
	$sql = 'update yycms_pintai set ' . arrtoupdate($_data) . ' where id = '.$_POST['pintai'].'';
	if (mysql_query($sql)) {
$file = '../sava/'.$_POST['pintai'].'.txt';	
unlink($file);	
$result = mysql_query('select * from yycms_pintai where id = '.$_POST['pintai'].'');
while ($record = mysql_fetch_array($result) )
{
$records[] = $record;
}
$OUTPUT = serialize($records);
$fp = fopen($file,"w"); // 以写权限的方式打开文件
fputs($fp, $OUTPUT);
		return json_encode(array('code' => '200', 'msg' => '修改成功'));
	} else {
		return json_encode(array('code' => '400', 'msg' => '修改失败'));
	}
	}
function hyzxxg()
{
if($_POST['id']==''){	
return json_encode(array('code' => '400', 'msg' => '请至少选中一项'));
}
	$s = '';
	$id = '';
	foreach ($_POST['id'] as $value) {
		$id .= $s . $value;
		$s = ',';
	}
	switch ($_POST['execute_method']) {
		case 'status':
			$sql = 'update yycms_user set b_zt = 1 where b_id in (' . $id . ')';
			break;
		case 'status1':
			$sql = 'update yycms_user set b_zt = 0 where b_id in (' . $id . ')';
			break;
		case 'delete':
			$sql = 'delete from yycms_user where b_id in (' . $id . ')';
			break;
		default:
			return json_encode(array('code' => '400', 'msg' => '请选择要执行的操作'));
	}
	mysql_query($sql);
	return json_encode(array('code' => '200', 'msg' => '执行成功'));
	}
function wxxg()
{
	$_data['wx_url'] = $_POST['yycms_wx_url'];
	$_data['wx_ts'] = $_POST['yycms_wx_ts'];
	$_data['wx_appid'] = $_POST['yycms_wx_appid'];
	$_data['wx_appsecret'] = $_POST['wx_appsecret'];
	$_data['wx_token'] = $_POST['yycms_wx_token'];
	$_data['wx_hf'] = $_POST['yycms_wx_hf'];
	$sql = 'update yycms_wx set ' . arrtoupdate($_data) . ' where wx_pingtai = 1';
	if (mysql_query($sql)) {
		return json_encode(array('code' => '200', 'msg' => '修改成功'));
	} else {
		return json_encode(array('code' => '400', 'msg' => '修改失败'));
	}
	}
function tjdl()
{
$_data['a_bt'] = $_POST['yycms_a_tb'];
$_data['a_name'] = $_POST['yycms_a_name'];
$_data['a_url'] = $_POST['yycms_a_url'];
$_data['a_keywords'] = $_POST['yycms_a_keywords'];
$_data['a_description'] = $_POST['yycms_a_description'];
$_data['a_bfqgg'] = $_POST['yycms_a_bfqgg'];
$_data['a_jzt'] = $_POST['yycms_a_jzt'];
$_data['a_hckg'] = $_POST['yycms_a_hckg'];
$_data['a_hcsj'] = $_POST['yycms_a_hcsj'];
$_data['a_logo'] = $_POST['yycms_a_logo'];
$_data['a_fhkg'] = $_POST['yycms_a_fhkg'];
$_data['a_mrjx'] = $_POST['yycms_a_mrjx'];
$_data['a_jxjk'] = $_POST['yycms_a_jxjk'];
$_data['a_zyjk'] = $_POST['yycms_a_zyjk'];
$_data['a_ggkg'] = '2';
$_data['a_gg'] = '2';
$_data['a_qqsp'] = $_POST['yycms_a_qqsp'];
$_data['a_bq'] = $_POST['yycms_a_bq'];
$_data['a_tj'] = addslashes($_POST['yycms_a_tj']);
$_data['a_dbdh'] = $_POST['yycms_a_dbdh'];
$_data['a_dylb'] = $_POST['yycms_a_dylb'];
$_data['a_dst'] = $_POST['yycms_a_dst'];
$_data['a_sfkg'] = $_POST['yycms_a_sfkg'];
$_data['a_wximg'] = $_POST['yycms_a_wximg'];
$_data['a_mb'] = $_POST['yycms_a_mb'];
$_data['a_kg1'] = $_POST['yycms_a_kg1'];
	$str = arrtoinsert($_data);
	$sql = 'insert into yycms_pintai (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
		return json_encode(array('code' => '200', 'msg' => '添加成功'));
	} else {
		return json_encode(array('code' => '400', 'msg' => '添加失败'));
	}
}
function dlsc()
{
$sql = 'delete from yycms_pintai where id in (' . $_POST['id'] . ')';
mysql_query($sql);
return json_encode(array('code' => '200', 'msg' => '删除成功'));
}
function lysc()
{
if($_POST['id']==''){	
return json_encode(array('code' => '400', 'msg' => '请至少选中一项'));
}
	$s = '';
	$id = '';
	foreach ($_POST['id'] as $value) {
		$id .= $s . $value;
		$s = ',';
	}
	switch ($_POST['execute_method']) {
		case 'delete':
			$sql = 'delete from yycms_ly where ly_id in (' . $id . ')';
			break;
		default:
			return json_encode(array('code' => '400', 'msg' => '请选择要执行的操作'));
	}
	mysql_query($sql);
	return json_encode(array('code' => '200', 'msg' => '执行成功'));
	}
function zfxg()
{
	$_data['zf_kg'] = $_POST['yycms_zf_kg'];
	$_data['zf_pay'] = $_POST['yycms_zf_pay'];
	$_data['zf_user'] = $_POST['yycms_zf_user'];
	$_data['zf_pass'] = $_POST['yycms_zf_pass'];
	$sql = 'update yycms_shoufei set ' . arrtoupdate($_data) . '';
	if (mysql_query($sql)) {
		return json_encode(array('code' => '200', 'msg' => '修改成功'));
	} else {
		return json_encode(array('code' => '400', 'msg' => '修改失败'));
	}
	}
function ylxg()
{
	$_data['yl_name'] = $_POST['yl_name'];
	$_data['yl_url'] = $_POST['yl_url'];
	$sql = 'update yycms_yl set ' . arrtoupdate($_data) . ' where yl_id = ' . $_POST['yy_id'] . '';
	if (mysql_query($sql)) {
		return json_encode(array('code' => '200', 'msg' => '修改成功'));
	} else {
		return json_encode(array('code' => '400', 'msg' => '修改失败'));
	}
	}
function yltj()
{
$_data['yl_url'] = $_POST['yl_url'];
$_data['yl_name'] = $_POST['yl_name'];
	$str = arrtoinsert($_data);
	$sql = 'insert into yycms_yl (' . $str[0] . ') values (' . $str[1] . ')';
	if (mysql_query($sql)) {
		return json_encode(array('code' => '200', 'msg' => '添加成功'));
	} else {
		return json_encode(array('code' => '400', 'msg' => '添加失败'));
	}
}
function ylsc()
{
$sql = 'delete from yycms_yl where yl_id = ' . $_POST['yl_id'] . '';
mysql_query($sql);
return json_encode(array('code' => '200', 'msg' => '删除成功'));
}
function sckms(){//卡密生成
	$title = $_POST['yycms_km_sj'];//套餐时间
	$weishu = $_POST['yycms_km_ws'];//位数
	$num = $_POST['yycms_km_sl'];//数量
	$kmbs =  mt_rand(1,999);
	//$time = time();
	$_data['name'] = $_POST['yycms_km_name'];
	$_data['sl'] = $_POST['yycms_km_sl'];
	$_data['tc'] = $_POST['yycms_km_sj'];
	$_data['bs'] = $kmbs;
	$str = arrtoinsert($_data);
	$sql = 'insert into yycms_kmadd (' . $str[0] . ') values (' . $str[1] . ')';
	mysql_query($sql);
	function getkm($_var_0 = 32)
	{
		$_var_1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		$_var_2 = strlen($_var_1);
		$_var_3 = '';
		for ($_var_4 = 0; $_var_4 < $_var_0; $_var_4++) {
			$_var_3 .= $_var_1[mt_rand(0, $_var_2 - 1)];
		}
		return $_var_3;
	}
	for ($i = 0; $i < $num; $i++) {
		$km = getkm($weishu);
		$SQL = "INSERT INTO `yycms_km` (`km_id`, `km_name`, `km_tc`, `km_zt`, `km_syz`, `km_bs`) VALUES (NULL, '{$km}', '{$title}', '0', '0', '{$kmbs}')";
		mysql_query($SQL);
	}
	//$sql = "INSERT INTO `mkcms_user_cardclass` (`uniacid`,`title`, `card_id`, `num`, `userid`, `day`) VALUES ('{$uniacid}','{$title}', '{$card_id}', '{$num}', '{$userid}', '{$day}')";
	//mysql_query($sql);
	mysql_close();
    return json_encode(array('code' => 200, 'msg' => '生成卡密成功，一共生成 ' . $num . ' 张卡密'));
}
function kmzsc()
{
$sql='delete from  yycms_km where km_bs='.$_POST['bs'].'';
$sqll='delete from  yycms_kmadd where bs='.$_POST['bs'].'';
	mysql_query($sqll);
	mysql_query($sql);
	return json_encode(array('code' => '200', 'msg' => '删除成功'));
	}
function kmsc()
{
if($_POST['id']==''){	
return json_encode(array('code' => '400', 'msg' => '请至少选中一项'));
}
	$s = '';
	$id = '';
	foreach ($_POST['id'] as $value) {
		$id .= $s . $value;
		$s = ',';
	}
	switch ($_POST['execute_method']) {
		case 'delete':
			$sql = 'delete from yycms_km where km_id in (' . $id . ')';
			break;
		default:
			return json_encode(array('code' => '400', 'msg' => '请选择要执行的操作'));
	}
	mysql_query($sql);
	return json_encode(array('code' => '200', 'msg' => '删除成功'));
	}
function spplsc()
{
if($_POST['id']==''){	
return json_encode(array('code' => '400', 'msg' => '请至少选中一项'));
}
	$s = '';
	$id = '';
	foreach ($_POST['id'] as $value) {
		$id .= $s . $value;
		$s = ',';
	}
	switch ($_POST['execute_method']) {
		case 'delete':
			$sql = 'delete from yycms_vod where b_id in (' . $id . ')';
			break;
		default:
			return json_encode(array('code' => '400', 'msg' => '请选择要执行的操作'));
	}
	mysql_query($sql);
	return json_encode(array('code' => '200', 'msg' => '删除成功'));
	}
function yhtj()
{
$b_name = isset($_POST['yycms_user_add']) ? trim($_POST['yycms_user_add']) : '';
$b_pass = md5(trim($_POST['yycms_poss_add']));
$query = mysql_query("select b_id from yycms_user where b_user='$b_name'");
if(mysql_fetch_array($query)){
return json_encode(array('code' => '400', 'msg' => '用户名存在'));
}
$yuming = $_SERVER['HTTP_HOST'];
$sql_jc = mysql_query("select * from yycms_pintai where a_url='$yuming'");
$row_jc   = mysql_fetch_array($sql_jc);
$hxlpintai_id = $row_jc['id'];
$data['b_pingtai'] = $hxlpintai_id;
$data['b_user'] = $b_name;
$data['b_pass'] =$b_pass;
$data['b_tg'] ='0';
$data['b_hy'] =$_POST['yycms_hy_add'];
$data['b_jf'] =$_POST['yycms_jf_add'];
$data['b_start'] =date('Y-m-d h:i:s', time());
$data['b_type'] =$_POST['yycms_type_add'];
$str = arrtoinsert($data);
$sqll = 'insert into yycms_user ('.$str[0].') values ('.$str[1].')';
if (mysql_query($sqll)) {
return json_encode(array('code' => '200', 'msg' => '添加成功'));
}else{
return json_encode(array('code' => '400', 'msg' => '添加失败'));
}	
}
function yhxg()
{
	$_data['b_hy'] =$_POST['yycms_hy_add'];
	$_data['b_user'] = $_POST['yycms_user_add'];
	$_data['b_jf'] =$_POST['yycms_jf_add'];
	$_data['b_type'] =$_POST['yycms_type_add'];
	$result = mysql_query('select * from yycms_user where b_id = ' . $_POST['yycms_id_add'] . '');
	if ($row = mysql_fetch_array($result)) {
		if ($_POST['yycms_poss_add'] != $row['b_pass']) {
			$_data['b_pass'] = md5($_POST['yycms_poss_add']);
		} else {
			$_data['b_pass'] = $_POST['yycms_poss_add'];
		}
	}
	$sql = 'update yycms_user set ' . arrtoupdate($_data) . ' where b_id = ' . $_POST['yycms_id_add'] . '';
	if (mysql_query($sql)) {
		return json_encode(array('code' => '200', 'msg' => '修改成功'));
	} else {
		return json_encode(array('code' => '400', 'msg' => '修改失败'));
	}
	}		
$a=$_POST['yycms'];
switch ($a){
	case "htdl":
        echo htdl();
        break;
	case "htxgmm":
        echo htxgmm();
        break;
	case "httc":
        echo httc();
        break;
    case "xtxg1":
        echo xtxg1();
        break;
	case "xgseo":
        echo xgseo();
        break;
    case "spxg":
        echo spxg();
        break;
	case "sptj":
        echo sptj();
        break;
	case "sclm":
        echo sclm();
        break;
	case "tjlm":
        echo tjlm();
        break;
	case "xglm":
        echo xglm();
        break;
	case "sfsz":
        echo sfsz();
        break;	
	case "ggxg":
        echo ggxg();
        break;	
	case "hyzxxg":
        echo hyzxxg();
        break;
	case "wxxg":
        echo wxxg();
        break;
	case "tjdl":
        echo tjdl();
        break;
	case "dlsc":
        echo dlsc();
        break;
	case "lysc":
        echo lysc();
        break;
	case "zfxg":
        echo zfxg();
        break;	
	case "ylxg":
        echo ylxg();
        break;	
	case "yltj":
        echo yltj();
        break;	
	case "ylsc":
        echo ylsc();
        break;	
	case "sckms":
        echo sckms();
        break;
    case "kmzsc":
        echo kmzsc();
        break;		
	case "kmsc":
        echo kmsc();
        break;
	case "spplsc":
        echo spplsc();
        break;
	case "yhtj":
        echo yhtj();
        break;
	case "yhxg":
        echo yhxg();
        break;
	   default:
        echo bc();
}	
?>