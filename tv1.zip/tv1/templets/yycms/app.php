<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $yycms_a_bt;?>影视APP</title>
<meta name="keywords" content="<?php echo $yycms_a_bt;?>影视APP在线下载">
<meta name="description" content="全网视频都能免费观看">
<?php
include 'head.php';
?>
</head>
<body class="yycmsys">
<?php 
include 'header.php';
?>
<div class="container">
        <div class="row">
<div class="myui-panel myui-panel-bg2 clearfix"> 
   <div class="myui-panel-box clearfix"> 
    <div class="myui-panel_bd"> 
     <div class="slideDown-box">    
<iframe id="iframe-player" name="iframe-player" src="/app/index.php" width="100%" height="600" scrolling="no" frameborder="0"></iframe>     
     </div> 
    </div> 
   </div> 
  </div>
    </div>
    </div>
<?php
include 'footer.php';
?>
</body>
</html>
