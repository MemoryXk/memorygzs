<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>歌曲大全_音乐下载_mp3歌曲免费下载,mp3歌曲免费下载网,<?php echo $yycms_a_bt;?></title>
<meta name="keywords" content="超好听的歌曲大全，在快快音乐。最具人气的流行音乐，最好听的MP3歌曲试听免费下载">
<meta name="description" content="歌曲大全,音乐下载,歌曲下载,歌曲Mp3,Mp3歌曲免费下载,歌曲试听">
<?php
include 'head.php';
?>
</head>
<body class="yycmsys">
<?php 
include 'header.php';
?>
<div class="container">
        <div class="row">
<div class="myui-panel myui-panel-bg2 clearfix"> 
   <div class="myui-panel-box clearfix"> 
    <div class="myui-panel_bd"> 
     <div class="slideDown-box">    
<iframe id="iframe-player" name="iframe-player" src="/y/index.html" width="100%" height="600" scrolling="no" frameborder="0"></iframe>     
     </div> 
    </div> 
   </div> 
  </div>
        </div>
    </div>
<?php
include 'footer.php';
?>
</body>
</html>