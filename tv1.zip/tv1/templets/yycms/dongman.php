<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>热门动漫-最新好看的动漫-<?php echo $yycms_a_bt;?></title>
<meta name="keywords" content="动漫,最新动漫,热门动漫,好看的动漫,动漫排行榜">
<meta name="description" content="为你提供最新最全动漫">
<?php
include 'head.php';
?>
</head>
<body class="yycmsys">
<?php 
$dm="active";
include 'header.php';
$yycmsfl="dongman";
$yycmszd="https://www.360kan.com";
include 'data/yycmsyslist.php';
$cs0=$_GET['rank'];//火热
if($cs0=='')$cs0='rankhot';
$cs1=$_GET['cat'];//类型
$cs2=$_GET['area'];//地区
$cs3=$_GET['year'];//年份
$cs4=$_GET['act'];//主演
$cs5=intval($_GET['pageno']);//页数
if($cs5=='')$cs5=1;
?>
<div class="container">
        <div class="row">
<div class="myui-panel myui-panel-bg2 clearfix"> 
   <div class="myui-panel-box clearfix"> 
    <div class="myui-panel_hd"> 
     <div class="myui-panel__head active bottom-line clearfix"> 
      <a class="slideDown-btn more pull-right" href="javascript:;">收起 <i class="fa fa-angle-up"></i></a> 
      <h3 class="title"><svg class="iconf" aria-hidden="true">
            <use xlink:href="#icon-shoucang"></use>
            </svg>动漫</h3> 

     </div> 
    </div> 
    <div class="myui-panel_bd"> 
     <div class="slideDown-box"> 
      <ul class="myui-screen__list nav-slide clearfix up-ul1" data-align="left">
       <li> <a class="text-muted btn">类型</a> </li> 
<li><a class="btn btn-warm" href="dongman_<?php echo $cs0 ?>_all_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html" >全部</a></li></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_100_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>热血</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_101_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>恋爱</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_102_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>美少女</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_103_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>运动</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_104_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>校园</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_105_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>搞笑</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_106_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>幻想</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_107_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>冒险</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_108_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>悬疑</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_109_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>魔幻</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_110_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>动物</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_111_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>少儿</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_131_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>亲子</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_112_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>机战</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_113_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>怪物</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_114_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>益智</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_115_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>战争</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_116_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>社会</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_117_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>友情</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_118_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>成人</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_119_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>竞技</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_120_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>耽美</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_121_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>童话</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_122_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>LOLI</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_123_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>青春</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_124_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>男性向</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_125_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>女性向</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_126_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>动作</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_127_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>真人版</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_128_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>OVA版</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_129_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>TV版</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_130_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>电影版</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_132_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>新番动画</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_133_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html' class='acat'>完结动画</a></li>

      </ul> 
      <ul class="myui-screen__list nav-slide clearfix up-ul3" data-align="left">
       <li> <a class="btn text-muted">年份</a> </li> 
<li><a class="btn btn-warm" href="dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_all_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html">全部</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2019_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2019</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2018_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2018</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2017_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2017</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2016_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2016</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2015_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2015</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2014_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2014</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2013_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2013</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2012_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2012</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2011_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2011</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2010_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2010</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2009_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2009</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2008_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2008</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_2007_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>2007</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_<?php echo $cs2 ?>_other_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>更早</a></li>
      </ul> 
      <ul class="myui-screen__list nav-slide clearfix up-ul4" data-align="left">
       <li> <a class="btn text-muted">地区</a> </li> 
<li><a class="btn btn-warm" href="dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_all_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html">全部</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_11_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>日本</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_12_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>美国</a></li>
<li><a class="btn" href='dongman_<?php echo $cs0 ?>_<?php echo $cs1 ?>_10_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html'>大陆</a></li>
      </ul> 
     </div> 
     <ul class="myui-screen__list nav-slide clearfix  up-ul5" data-align="left">
      <li> <a class="btn text-muted">排序</a> </li> 
      <li><a class="btn btn-warm" href="dongman_rankhot_<?php echo $cs1 ?>_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html">热映</a></li> 
      <li><a class="btn" href="dongman_createtime_<?php echo $cs1 ?>_<?php echo $cs2 ?>_<?php echo $cs3 ?>_<?php echo $cs5 ?>_<?php echo $cs5 ?>.html">最新</a></li> 
     </ul> 
    </div> 
   </div> 
  </div>        	
<!-- 筛选 -->
			
<div class="myui-panel myui-panel-bg clearfix"> 
   <div class="myui-panel-box clearfix"> 
    <div class="myui-panel_bd"> 
     <ul class="myui-vodlist clearfix"> 
<?php
foreach ($yycms['yycmsys'] as $yycmsys){
?>
      <li class="col-lg-7 col-md-7 col-sm-4 col-xs-3"> 
       <div class="myui-vodlist__box"> 
        <a class="myui-vodlist__thumb lazyload" href="/vod/<?php echo ltrim($yycmsys['yycmsys_url'], "/"); ?>" target="_blank" title="<?php echo $yycmsys['yycmsys_name']; ?>" data-original="<?php echo $yycmsys['yycmsys_pic']; ?>"> 
		<span class="play hidden-xs"></span> 
		<span class="pic-text text-right"><?php echo  $yycmsys['yycmsys_content']; ?></span> 
		</a> 
        <div class="myui-vodlist__detail"> 
         <h4 class="title text-overflow"><a href="/vod/<?php echo ltrim($yycmsys["yycmsys_url"], "/"); ?>" target="_blank" title="<?php echo $yycmsys['yycmsys_name']; ?>"><?php echo $yycmsys['yycmsys_name']; ?></a></h4> 
         <p class="text text-overflow text-muted hidden-xs"><?php echo $yycmsys['yycmsys_actor']; ?></p> 
        </div> 
       </div>
        </li> 
<?php 
}
?>
<?php
if(count($yycms['yycmsys']) <=0 ){ echo '<p style="text-align:center;color: #ffff;font-size: 20px;background: #bd2a437d;padding:11px 8px;border-radius: 2px;"><a href="szy.html"><span style="color:#FFFF;">
                没找到符合条件的电影，请尝试其他分类！</a></span></p></div>';}	   
?>
	   <!-- 列表-->
     </ul> 
    </div> 
   </div> 
  </div>
			
			<ul class="myui-page text-center clearfix">
<?php echo ggetPageHtml($cs5,$yycms['yycmsys_total'],'dongman','btn btn-default','btn  btn-warm','hidden-xs');?><li><a>共<?php echo $cs5?>/<?php echo $yycms['yycmsys_total'];?>页</a></li>	
</ul>
<!-- 翻页-->		
			
        </div>
    </div>

<?php
include 'footer.php';
?>
</body>
</html>	