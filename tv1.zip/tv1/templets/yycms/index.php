<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $yycms_a_bt;?></title>
<meta name="keywords" content="<?php echo $yycms_a_keywords;?>" />
<meta name="description" content="<?php echo $yycms_a_description;?>" />   
<?php
include 'head.php';
?>
<style type="text/css">
.myui-header__top{ background: linear-gradient(to bottom, rgba(0,0,0,0.7) 0%,rgba(0,0,0,0) 100%);}
</style>
</head>
<body>
<?php
$index="active";
include 'header.php';
?>
<div id="home_slide" class="carousel slide clearfix" data-ride="carousel"> 
   <div class="carousel-inner"> 
<?php 
$i=0;
foreach ($one as $ni=>$cs){
if ($i<7){
echo '
<div class="item text-center ';
if ($i<1){echo 'active';}
echo '"><a title="" href="../vod/m/'.$cs.'"> <img class="img-responsive hidden-xs" src="'.$two[$ni].'" /> <img style="height:200px;" class="img-responsive visible-xs" src="'.$two[$ni].'" /> </a>
</div>
';
$i ++;}}
?>
</div> 
<ul class="carousel-indicators carousel-indicators-thumb hidden-md hidden-sm hidden-xs"> 	
<?php 
$i=0;
foreach ($one as $ni=>$cs){
if ($i<7){
$cs= str_replace('/', '/m/', "$cs");
echo '<li data-target="#home_slide" data-slide-to="'.$i.'" class="';
if ($i<1){echo 'active';}
echo '" style="width: 160px; height: 80px;"><img class="img-responsive" style="max-width: 200%;" src="'.$two[$ni].'" /> </li>';
$i ++;}}?>


</ul> 
   <a class="carousel-control left" href="#home_slide" data-slide="prev"><i class="fa fa-angle-left"></i></a> 
   <a class="carousel-control right" href="#home_slide" data-slide="next"><i class="fa fa-angle-right"></i></a> 
  </div> 
<div class="stui-pannel stui-pannel-screen hidden-sm hidden-xs clearfix" style="margin-bottom: 0;">
<div class="stui-pannel-box">
<div class="container">
<div class="row">
<ul class="stui-index__screen col-pd clearfix">
<li class="type-slide m-bottom-line">
<a href="movie.html"><dt>电<br>    影</dt></a>
<a href='movie_all_103_all_all_all__.html'>喜剧</a>
<a href='movie_all_100_all_all_all__.html'>爱情</a>
<a href='movie_all_106_all_all_all__.html'>动作</a>
<a href='movie_all_102_all_all_all__.html'>恐怖</a>
<a href='movie_all_104_all_all_all__.html'>科幻</a>
<a href='movie_all_112_all_all_all__.html'>剧情</a>
</li>		
<li class="type-slide m-bottom-line">
<a href="tv.html"><dt>剧<br>    集</dt></a>
<a href='tv_all_103_all_all_all__.html'>警匪</a>
<a href='tv_all_108_all_all_all__.html'>悬疑</a>
<a href='tv_all_111_all_all_all__.html'>都市</a>
<a href='tv_all_100_all_all_all__.html'>偶像</a>
<a href='tv_all_104_all_all_all__.html'>古装</a>
<a href='tv_all_107_all_all_all__.html'>军事</a>
</li>
<li class="type-slide m-bottom-line">
<a href="zongyi.html"><dt>综<br>    艺</dt></a>
<a href='zongyi_all_101_all_all__.html'>选秀</a>
<a href='zongyi_all_107_all_all__.html'>搞笑</a>
<a href='zongyi_all_103_all_all__.html'>访谈</a>
<a href='zongyi_all_112_all_all__.html'>体育</a>
<a href='zongyi_all_113_all_all__.html'>纪实</a>
<a href='zongyi_all_114_all_all__.html'>科教</a>
</li>
<li class="type-slide m-bottom-line">
<a href="dongman.html"><dt>动<br>    漫</dt></a>
<a href='dongman_all_100_all_all__.html' class='acat'>热血</a>
<a href='dongman_all_101_all_all__.html' class='acat'>恋爱</a>
<a href='dongman_all_104_all_all__.html' class='acat'>校园</a>
<a href='dongman_all_106_all_all__.html' class='acat'>幻想</a>
<a href='dongman_all_118_all_all__.html' class='acat'>成人</a>
<a href='dongman_all_108_all_all__.html' class='acat'>悬疑</a>
</li>
</ul>
</div>
</div>
</div>
</div>
  <!-- 公告start -->
<div class="stui-pannel-bg clearfix" style="background-color: #ff6600;">
<div class="clearfix">
<div class="container stui-pannel_hd">
<div class="stui-pannel__head clearfix">
	<li class="active">
		<table border="0" width="100%">
			<tbody><tr>
			<td width="22" height="22">
			<img src="img/notice.png" width="22" height="22">
			</td>
			<td width="12" height="22"></td>
			<td><strong><marquee scrollamount="6" direction="left" align="Middle" style="padding-right:20px;color:#fff;">公告：欢迎光临优艺影院，建议手机安装app观看。本站不收取任何费用，只为满足个人爱好。<?php echo $mkcms_gonggao;?></marquee></strong></td>
			</tr>
			</tbody>
		</table>
	</li>
  </div>
  </div>
</div>
</div><!-- 公告end -->	
  <!-- 轮播 --> 
  <div class="container"> 
   <div class="row"> 
<?php 
if($yycms_a_dylb=="1"){
?>	 
    <div class="myui-panel myui-panel-bg clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_hd"> 
       <div class="myui-panel__head clearfix"> 
        <span class="text-muted more pull-right"></span> 
        <h3 class="title"><svg class="iconf" aria-hidden="true">
            <use xlink:href="#icon-dianying"></use>
            </svg>24小时电影轮播</h3> 
       </div> 
      </div> 
      <div class="myui-panel_bd clearfix"> 
       <ul class="myui-vodlist clearfix yycms">	 

<?php
$i=0;
foreach ($zb['dyzb'] as $key1 => $value1) {
if ($i<8){	
?>	
        <li class="col-lg-8  col-md-8 col-sm-4 col-xs-3 <?php if ($i>=6){echo 'hidden-xs';}?>"> 
         <div class="myui-vodlist__box"> 
                   <a class="myui-vodlist__thumb lazyload" data-url="/ck/zb.php?url=<?php echo $value1['url']; ?>" title="<?php echo $value1['name']; ?>" data-original="<?php echo $value1['img']; ?>"> 
		  <span class="play hidden-xs"></span>
		  <span class="pic-tag pic-tag-top" style="background-color: #5bb7fe;">直播</span> 
		  <span class="pic-text text-right"> </span> </a> 
          <div class="myui-vodlist__detail"> 
           <h4 class="title text-overflow"><a title="<?php echo $value1['name']; ?>"><?php echo $value1['name']; ?></a></h4> 
           <p class="text text-overflow text-muted hidden-xs"> <?php echo $value1['name']; ?></p> 
          </div> 
         </div> 
		 </li>
<?php
$i ++;}
}?> 
       </ul> 
      </div> 
     </div> 
    </div> 
<?php
}
?>	
<?php if(!$records[0]['gg_gg1']==""){
echo '<div class="myui-panel myui-panel-bg clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_bd"> 
       <div class="col-xs-1"> 
	   '.$records[0]['gg_gg1'].'
       </div> 
      </div> 
     </div> 
    </div>';	
}
?>
<?php 



if($yycms_a_kg1=="1"){
?>	
	  <!-- 抢先看 --> 
<div class="myui-panel myui-panel-bg clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_bd clearfix"> 
       <div class="col-lg-wide-76 col-md-wide-76 col-xs-1 padding-0"> 
        <div class="myui-panel_hd"> 
         <div class="myui-panel__head clearfix"> 
          <h3 class="title"><svg class="iconf" aria-hidden="true">
            <use xlink:href="#icon-zhuye2"></use>
            </svg>抢先看</h3> 
          <a class="more pull-right" href="/qxk.html">更多 <i class="fa fa-angle-right"></i></a> 
         </div> 
        </div> 
        <ul class="myui-vodlist clearfix"><!--想要自动显示最新入库 去掉下发的这个 where b_tj=1 --> 
<?php 
$result = mysql_query('select * from yycms_vod where b_tj=1 order by b_id desc LIMIT 0,12');
while ($row = mysql_fetch_array($result)){
?>					
<li class="col-lg-6 col-md-6 col-sm-4 col-xs-3"> 
          <div class="myui-vodlist__box"> 
           <a class="myui-vodlist__thumb lazyload" href="/qxplay/<?php echo $row['b_id'] ?>.html" title="<?php echo $row['b_name']; ?>" data-original="<?php echo $row['b_tp']; ?>"> 
		   <span class="play hidden-xs"></span> 
		   <span class="pic-tag pic-tag-top" style="background-color: #ef8211;">抢先</span> 
		   <span class="pic-text text-right"></span> 
		   </a> 
           <div class="myui-vodlist__detail"> 
            <h4 class="title text-overflow"><a href="/qxplay/<?php echo $row['b_id'] ?>.html" title="<?php echo $row['b_name']; ?>"><?php echo $row['b_name']; ?></a></h4> 
			<p class="text text-overflow text-muted hidden-xs"><?php echo $row['b_zy']; ?></p>
           </div> 
          </div>
		  </li> 					
<?php 
}
?>     
        </ul> 
       </div> 

      </div> 
     </div> 
    </div> 
<?php 
}
?> 	
 <!-- 最新电影 --> 
<div class="myui-panel myui-panel-bg clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_bd clearfix"> 
       <div class="col-lg-wide-76 col-md-wide-76 col-xs-1 padding-0"> 
        <div class="myui-panel_hd"> 
         <div class="myui-panel__head clearfix"> 
          <h3 class="title"><svg class="iconf" aria-hidden="true">
            <use xlink:href="#icon-luxiang"></use>
            </svg>最新电影</h3> 
          <a class="more text-muted" href="/movie.html">更多 <i class="fa fa-angle-right"></i></a> 
         </div> 
        </div> 
        <ul class="myui-vodlist clearfix"> 
         
<?php 
include('data/yycmsyslist2.php');
$i=0;
foreach (yycmsys('https://www.360kan.com','dianying',$yycms_a_hckg,$yycms_a_hcsj) as $k=>$yycmsys)
{if ($i<12){
echo '<li class="col-lg-6 col-md-6 col-sm-4 col-xs-3"> 
          <div class="myui-vodlist__box"> 
           <a class="myui-vodlist__thumb lazyload" href="../vod/'.ltrim($yycmsys['yycmsys_url'], "/").'" title="'.$yycmsys['yycmsys_name'].'" data-original="'.$yycmsys['yycmsys_pic'].'"> 
		   <span class="play hidden-xs"></span> 
		   <span class="pic-tag pic-tag-top" style="background-color: #ef8211;">'.$yycmsys['yycmsys_point'].'</span> 
		   <span class="pic-text text-right">'.$yycmsys['yycmsys_content'].'</span> 
		   </a> 
           <div class="myui-vodlist__detail"> 
            <h4 class="title text-overflow"><a href="../vod/'.ltrim($yycmsys['yycmsys_url'], "/").'" title="'.$yycmsys['yycmsys_name'].'">'.$yycmsys['yycmsys_name'].'</a></h4> 
			<p class="text text-overflow text-muted hidden-xs">'.$yycmsys['yycmsys_actor'].'</p>
           </div> 
          </div>
		  </li> ';
$i ++;}
} ?>        
        </ul> 
       </div> 

      </div> 
     </div> 
    </div> 		
<?php if(!$records[0]['gg_gg2']==""){
echo '<div class="myui-panel myui-panel-bg clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_bd"> 
       <div class="col-xs-1"> 
	   '.$records[0]['gg_gg2'].'
       </div> 
      </div> 
     </div> 
    </div>';	
}
?>		
    <!-- 电视剧 -->     
    <div class="myui-panel myui-panel-bg clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_bd clearfix"> 
       <div class="col-lg-wide-76 col-md-wide-76 col-xs-1 padding-0"> 
        <div class="myui-panel_hd"> 
         <div class="myui-panel__head clearfix"> 
          <h3 class="title"><svg class="iconf" aria-hidden="true">
            <use xlink:href="#icon-yanglazhuye"></use>
            </svg>热播剧集</h3> 
          <a class="more text-muted" href="/tv.html">更多 <i class="fa fa-angle-right"></i></a> 
         </div> 
        </div> 
        <ul class="myui-vodlist clearfix"> 
<?php

$i=0;
foreach (yycmsys('https://www.360kan.com','dianshi',$yycms_a_hckg,$yycms_a_hcsj) as $k=>$yycmsys)
{if ($i<12){
echo '<li class="col-lg-6 col-md-6 col-sm-4 col-xs-3"> 
          <div class="myui-vodlist__box"> 
           <a class="myui-vodlist__thumb lazyload" href="../vod/'.ltrim($yycmsys['yycmsys_url'], "/").'" title="'.$yycmsys['yycmsys_name'].'" data-original="'.$yycmsys['yycmsys_pic'].'"> 
		   <span class="play hidden-xs"></span> 
		   <span class="pic-text text-right">'.$yycmsys['yycmsys_content'].'</span> 
		   </a> 
           <div class="myui-vodlist__detail"> 
            <h4 class="title text-overflow"><a href="../vod/'.ltrim($yycmsys['yycmsys_url'], "/").'" title="'.$yycmsys['yycmsys_name'].'">'.$yycmsys['yycmsys_name'].'</a></h4> 
			<p class="text text-overflow text-muted hidden-xs">'.$yycmsys['yycmsys_actor'].'</p>
           </div> 
          </div>
		  </li> ';
$i ++;}
} ?> 
        </ul> 
       </div> 

      </div> 
     </div> 
    </div> 
<?php if(!$records[0]['gg_gg3']==""){
echo '<div class="myui-panel myui-panel-bg clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_bd"> 
       <div class="col-xs-1"> 
	   '.$records[0]['gg_gg3'].'
       </div> 
      </div> 
     </div> 
    </div>';	
}
?>
    <!-- 最新综艺 -->     
    <div class="myui-panel myui-panel-bg clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_bd clearfix"> 
       <div class="col-lg-wide-76 col-md-wide-76 col-xs-1 padding-0"> 
        <div class="myui-panel_hd"> 
         <div class="myui-panel__head clearfix"> 
          <h3 class="title"><svg class="iconf" aria-hidden="true">
            <use xlink:href="#icon-qita"></use>
            </svg>热播综艺</h3> 
          <a class="more text-muted" href="/zongyi.html">更多 <i class="fa fa-angle-right"></i></a> 
         </div> 
        </div> 
        <ul class="myui-vodlist clearfix"> 
<?php
$i=0;
foreach (yycmsys('https://www.360kan.com','zongyi',$yycms_a_hckg,$yycms_a_hcsj) as $k=>$yycmsys)
{if ($i<12){
echo '<li class="col-lg-6 col-md-6 col-sm-4 col-xs-3"> 
          <div class="myui-vodlist__box"> 
           <a class="myui-vodlist__thumb lazyload" href="../vod/'.ltrim($yycmsys['yycmsys_url'], "/").'" title="'.$yycmsys['yycmsys_name'].'" data-original="'.$yycmsys['yycmsys_pic'].'"> 
		   <span class="play hidden-xs"></span> 
		   <span class="pic-text text-right">'.$yycmsys['yycmsys_content'].'</span> 
		   </a> 
           <div class="myui-vodlist__detail"> 
            <h4 class="title text-overflow"><a href="../vod/'.ltrim($yycmsys['yycmsys_url'], "/").'" title="'.$yycmsys['yycmsys_name'].'">'.$yycmsys['yycmsys_name'].'</a></h4> 
			<p class="text text-overflow text-muted hidden-xs">'.$yycmsys['yycmsys_actor'].'</p>
           </div> 
          </div>
		  </li> ';
$i ++;}
} ?> 
        </ul> 
       </div> 

      </div> 
     </div> 
    </div>    
<?php if(!$records[0]['gg_gg4']==""){
echo '<div class="myui-panel myui-panel-bg clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_bd"> 
       <div class="col-xs-1"> 
	   '.$records[0]['gg_gg4'].'
       </div> 
      </div> 
     </div> 
    </div>';	
}
?>
    <!-- 最新动漫 -->     
    <div class="myui-panel myui-panel-bg clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_bd clearfix"> 
       <div class="col-lg-wide-76 col-md-wide-76 col-xs-1 padding-0"> 
        <div class="myui-panel_hd"> 
         <div class="myui-panel__head clearfix"> 
          <h3 class="title"><svg class="iconf" aria-hidden="true">
            <use xlink:href="#icon-shoucang"></use>
            </svg>热播动漫</h3> 
          <a class="more text-muted" href="/dongman.html">更多 <i class="fa fa-angle-right"></i></a> 
         </div> 
        </div> 
        <ul class="myui-vodlist clearfix"> 
<?php
$i=0;
foreach (yycmsys('https://www.360kan.com','dongman',$yycms_a_hckg,$yycms_a_hcsj) as $k=>$yycmsys)
{if ($i<12){
echo '<li class="col-lg-6 col-md-6 col-sm-4 col-xs-3"> 
          <div class="myui-vodlist__box"> 
           <a class="myui-vodlist__thumb lazyload" href="../vod/'.ltrim($yycmsys['yycmsys_url'], "/").'" title="'.$yycmsys['yycmsys_name'].'" data-original="'.$yycmsys['yycmsys_pic'].'"> 
		   <span class="play hidden-xs"></span> 
		   <span class="pic-text text-right">'.$yycmsys['yycmsys_content'].'</span> 
		   </a> 
           <div class="myui-vodlist__detail"> 
            <h4 class="title text-overflow"><a href="../vod/'.ltrim($yycmsys['yycmsys_url'], "/").'" title="'.$yycmsys['yycmsys_name'].'">'.$yycmsys['yycmsys_name'].'</a></h4> 
			<p class="text text-overflow text-muted hidden-xs">'.$yycmsys['yycmsys_actor'].'</p>
           </div> 
          </div>
		  </li> ';
$i ++;}
} ?> 
        </ul> 
       </div> 

      </div> 
     </div> 
    </div>    
<?php if(!$records[0]['gg_gg5']==""){
echo '<div class="myui-panel myui-panel-bg clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_bd"> 
       <div class="col-xs-1"> 
	   '.$records[0]['gg_gg5'].'
       </div> 
      </div> 
     </div> 
    </div>';	
}
?>
 <!-- 合作 --> 
    <div class="myui-panel myui-panel-bg hidden-xs clearfix"> 
     <div class="myui-panel-box clearfix"> 
      <div class="myui-panel_hd"> 
       <div class="myui-panel__head clearfix"> 
       <h3 class="title"><img src="/img/icon_yl.png">友情链接</h3>
       </div> 
      </div> 
      <div class="myui-panel_bd clearfix"> 
       <div class="col-xs-1"> 
        <ul class="myui-link__text clearfix"> 
<?php
$result = mysql_query('select * from yycms_yl');
while($row = mysql_fetch_array($result)){
?>
<li><a class="text-muted" href="<?php echo $row['yl_url'];?>" title="<?php echo $row['yl_name'];?>" target="_blank"><?php echo $row['yl_name'];?></a></li> 
<?php
}
?>
        </ul> 
       </div> 
      </div> 
     </div> 
    </div> 
    <!-- 友链 --> 
   </div> 
  </div>
<?php
include 'footer.php';
?>
</body>
</html>	