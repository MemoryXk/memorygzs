<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $minx;?><?php echo $nian;?>电视剧大全-<?php echo $minx;?><?php echo $nian;?>电视剧排行榜-<?php echo $yycms_a_bt;?></title>
<meta name="keywords" content="<?php echo $minx;?><?php echo $nian;?>电视剧">
<meta name="description" content="为您提供<?php echo $minx;?><?php echo $nian;?>电视剧排行榜">
<?php
include 'head.php';
?>
</head>
<body class="yycmsys">
<?php 
$qxk="active";
include 'header.php';
$cs5=intval($_GET['page']);//页数
if($cs5=='')$cs5=1;
?>
<div class="container">
        <div class="row">
<!--<div class="myui-panel myui-panel-bg clearfix" style="background-color: #3b3939;">
	<div class="myui-panel-box clearfix">
		<div class="myui-panel_bd">		
			<div class="flickity clearfix" data-align="left" data-next="1">
								<div class="col-lg-8  col-md-6 col-sm-4 col-xs-3">
					<div class="myui-vodlist__box">
	<a href="" class="myui-vodlist__thumb lazyload" title="" data-original="">	
		<span class="play hidden-xs"></span>
			<span class="pic-tag pic-tag-top" style="background-color: #5bb7fe;">
				2.1分
			</span>
		<span class="pic-text text-center"></span>
	</a>																				
</div>												
				</div>



														
			</div>																					
    	</div>
   </div>
</div>-->
<!-- 推荐 -->
<div class="myui-panel myui-panel-bg2 clearfix"> 
   <div class="myui-panel-box clearfix"> 
    <div class="myui-panel_hd"> 
     <div class="myui-panel__head active bottom-line clearfix"> 
      <h3 class="title"><svg class="iconf" aria-hidden="true">
            <use xlink:href="#icon-dianzan"></use>
            </svg>抢先看</h3> 

     </div> 
    </div> 
    <div class="myui-panel_bd"> 
     <div class="slideDown-box"> 
      <ul class="myui-screen__list nav-slide clearfix up-ul1" data-align="left"> 
       <li> <a class="text-muted btn">类型</a> </li> 
<li><a class="btn btn-warm" href="./qxk-0-1.html">全部</a></li>
<?php
$result = mysql_query('select * from yycms_vod_class where c_pid=0 order by c_sort asc');
while ($row = mysql_fetch_array($result)){
echo '<li><a class="btn" href="./qxk-'.$row['c_id'].'-1.html">'.$row['c_name'].'</a></li>';
}
?>
<?php
if ($_GET['cid'] != 0){
	?>
<?php
$result = mysql_query('select * from yycms_vod_class where c_pid='.$_GET['cid'].' order by c_sort desc,c_id asc');
while ($row = mysql_fetch_array($result)){
echo '<li><a class="btn" href="./qxk-'.$row['c_id'].'-1.html">'.$row['c_name'].'</a></li>';
}
?>
<?php }?>
      </ul> 
     </div> 
    </div> 
   </div> 
  </div>        	
<!-- 筛选 -->
		<?php			  
		$query="select count(*) from yycms_vod";
		$queryy="select count(*) from yycms_vod where `b_time` like '".date("Y-m-d",time())."%';";
				$result = mysql_query($query,$conn);
				$resultt = mysql_query($queryy,$conn);
				$rowtotle = mysql_fetch_array($result);
				$rowtotlee = mysql_fetch_array($resultt);
				$totle=$rowtotle[0];
				$totlee=$rowtotlee[0];
		
		?>				
<div class="myui-panel myui-panel-bg clearfix"> 
   <div class="myui-panel-box clearfix"> 
    <div class="myui-panel_bd"> 
     <ul class="myui-vodlist clearfix"> 
 							<?php
							if ($_GET['cid']== 0) {	
									$sql = 'select * from yycms_vod order by b_id desc';
									$pager = page_handle('page',20,mysql_num_rows(mysql_query($sql)));
									$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');
								}else{
                                     $sql = 'select * from yycms_vod where b_fl in ('.$_GET['cid'].') order by b_id desc';
									$pager = page_handle('page',20,mysql_num_rows(mysql_query($sql)));
									$result = mysql_query($sql.' limit '.$pager[0].','.$pager[1].'');
								}
							while($row= mysql_fetch_array($result)){
?>
<li class="col-lg-7 col-md-7 col-sm-4 col-xs-3"> 
       <div class="myui-vodlist__box"> 
        <a class="myui-vodlist__thumb lazyload" href="/qxplay/<?php echo $row['b_id'] ?>.html" target="_blank" title="<?php echo $row['b_name']; ?>" data-original="<?php echo $row['b_tp']; ?>"> 
		<span class="play hidden-xs"></span> 
		<span class="pic-tag pic-tag-top" style="background-color: #5bb7fe;"></span>
		<span class="pic-text text-right"></span> 
		</a> 
        <div class="myui-vodlist__detail"> 
         <h4 class="title text-overflow"><a href="/vod/ct/OU4mb57lMYGuCT.html" target="_blank" title="<?php echo $row['b_name']; ?>"><?php echo $row['b_name']; ?></a></h4> 
         <p class="text text-overflow text-muted hidden-xs"><?php echo $row['b_zy']; ?></p> 
        </div> 
       </div>
        </li> 
<?php
 } 
 ?>
	   <!-- 列表-->
     </ul> 
    </div> 
   </div> 
  </div>		
			<ul class="myui-page text-center clearfix">
<?php echo pagee_show($cs5,$pager[2],'qxk','btn btn-default','btn  btn-warm','hidden-xs');?><li><a>共<?php echo $cs5;?>/<?php echo $pager[2];?>页</a></li>	
</ul>
<!-- 翻页-->		
			
        </div>
    </div>

<?php
include 'footer.php';
?>
</body>
</html>
