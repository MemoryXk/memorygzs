<?php
error_reporting(E_ALL^E_DEPRECATED);
ob_start();
error_reporting(0); //雨雨CMS作者QQ:201232694
//if (!session_id()) session_start();
define('PCFINAL', TRUE);
date_default_timezone_set('PRC');//设置时区
header('Content-type:text/html; charset=utf-8');//设置编码
include('data.php');
$conn = mysql_connect(DATA_HOST, DATA_USERNAME, DATA_PASSWORD);
mysql_select_db(DATA_NAME);
mysql_query('set names utf8');
// 定义版本
define('YYCMS_VERSION', 'yycms-v1.0.0');
?>