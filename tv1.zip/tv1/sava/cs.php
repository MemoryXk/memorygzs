<?php
require_once('conn.php');
error_reporting(0); 
$sql = "insert into yycms_user (b_user,b_pass,b_tg) values('123456','123456','123456')";
if (mysql_query($sqll)) {
return json_encode(array('code' => '200', 'msg' => '注册成功'));
}	
?>