<?php
error_reporting(0);
function unicode_decode($name){
	$json = '{"str":"'.$name.'"}';
	$arr = json_decode($json,true);
	if(empty($arr)) return '';
	return $arr['str'];
}
$urllist='https://www.360kan.com'.$_GET['play']; 
mkdir('./cache');
mkdir('./cache/bofang');
if($yycms_a_hckg == '1'){
$gxpd=time()-filemtime('./cache/bofang/'.md5($urllist));
if($gxpd>$yycms_a_hcsj*60*60){
$info=gett($urllist);
file_put_contents('./cache/bofang/'.md5($urllist),gzdeflate($info));
}
$tvinfo=gzinflate(file_get_contents('./cache/bofang/'.md5($urllist)));
}else{
$tvinfo=gett($urllist);
}
preg_match('#/(.*?)/(.*?).html#', $_GET['play'], $aaa);
//用地址数组第一位区分影片类型：电影：m;电视剧：tv;综艺：va;动漫:ct
$dyPrefix="m";$dsjPrefix="tv";$zyPrefix="va";$dmPrefix="ct";
$Prefix=$aaa[1];
$c=$aaa[2];
$tvzz='#<div class="(site-wrap"\s*id="js-site-wrap)?(num-tab-main\s*g-clear\s*js-tab)?(num-tab-main\s*g-clear\s*js-tab"\s*style="display:none;)?">[\s\S]+?<a data-num="(.*?)"\s*data-daochu="to=(.*?)" href="(.*?)">[\s\S]+?</div>#';
$tvzz1 = '#<a data-num="(.*?)"\s*data-daochu="to=(.*?)" href="(.*?)">#';
$tvyzze='#playsite:(.*?)],#';
$jiekoucat='#cat: \'(.*?)\',#';
$dyzz= '# <span class="txt">站点排序 ：</span>[\s\S]+?<div style=\' visibility:hidden\'#';
$bflist = '#<a data-daochu=(.*?) class="btn js-site ea-site (.*?)" href="(.*?)">(.*?)</a>#';
$jianjie = '#<div class="item-desc-wrap g-clear js-close-wrap" style="display:none;">([\s\S]*?)<a#';
$biaoti = '#<h1>(.*?)</h1>#';
$pan = '#<h2 class="title g-clear">(.*?)</h2>#';
$pan1 = '#<h2 class="g-clear">(.*?)</h2>#';
$niandai = '#<p class="ite(.*?)"><span>年代(.*?)</span>(.*?)</p>#';
$diqu = '#<p class="ite(.*?)"><span>地区(.*?)</span>(.*?)</p>#';
preg_match_all($jianjie, $tvinfo, $jjarr);
preg_match_all($tvzz, $tvinfo, $tvarr);
preg_match_all($dyzz, $tvinfo, $dyarr);
preg_match_all($pan, $tvinfo, $ptvarr);
preg_match_all($pan1, $tvinfo, $ptvarr1);
preg_match_all($dyzz, $tvinfo, $tvlist);
preg_match_all($biaoti, $tvinfo, $btarr);
$mvsrc = implode($glue, $tvlist[0]);
preg_match_all($bflist, $mvsrc, $dyarr1);
//preg_match_all($tvyzjihe, $tvinfo, $tvyzhtml);
preg_match_all($tvyzze, $tvinfo, $tvyzarr);
preg_match_all($niandai, $tvinfo, $niandaio);
preg_match_all($diqu, $tvinfo, $diquo);
preg_match_all($jiekoucat, $tvinfo, $jiekoucat1);
//print_r($dyarr1[0]);
$dysrc=$dyarr1[0];
$c=$dyarr1[3];//电影的播放链接
foreach ($c as $k => $Rc) {//屏蔽优酷付费视频跳转
	$c[$k] = str_replace("http://cps.youku.com/redirect.html?id=0000028f&url=", "", $Rc);
}
$d=$dyarr1[4];//电影来源
$jian = $jjarr[1][0];//简介
$timu = $btarr[1][0];//标题
$panduan = $ptvarr[1][0];
$panduan1 = $ptvarr1[1][0];
$g=$niandaio[3][0];
$h=$diquo[3][0];
//$zyv="#<div class=\"juji-main\">[\s\S]+?<div class=\"juji-page\">#";
//2018-09-28修复综艺播放连接不显示
$zyv="#<div id=\"js-year-all\" class=\"js-month-tab g-clear\">[\s\S]+?<div style=\"display:none;\" class=\"js-month-tab\">#";
$qi="#<span class='w-newfigure-hint'>(.*?)</span>#";
$zyimg="#data-src='(.*?)' alt='(.*?)'#";
preg_match_all($zyv, $tvinfo,$zyvarr);
$zylist = implode($glue, $zyvarr[0]);

$ztlizz="#<a href='(.*?)' data-daochu=to=(.*?) class='js-link'><div class='w-newfigure-imglink g-playicon js-playicon'>#";
preg_match_all($ztlizz, $zylist,$zyliarr);
preg_match_all($qi, $zylist,$qiarr);
preg_match_all($zyimg, $zylist,$imgarr);
$zyvi=$zyliarr[1];
//print_r($zyvi);
$noqi=$qiarr[1];
$zypic=$imgarr[1];
$zyname=$imgarr[2];
$mvsrc1 = str_replace("http://cps.youku.com/redirect.html?id=0000028f&url=", "", "$dysrc");
$zcf = implode($glue, $tvarr[0]);
preg_match_all($tvzz1, $zcf, $tvarr1);
$b = $tvarr1[3];
$much = 1;
?>