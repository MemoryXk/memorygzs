<?php
require_once('conn.php');
require_once('function.php');
error_reporting(0); //雨雨CMS作者QQ:201232694
header("Content-type:text/json");
//错误提示
function bc()
{
return json_encode(array('code' => '400', 'msg' => '操作失败'));
}
function CheckUrl($C_url){//过滤注册  
     $str="/ |‖|\/|\~|\!|\@|\#|\\$|\%|\^|\&|\*|\(|\)|\_|\+|\{|\}|\:|\<|\>|\?|\[|\]|\,|\.|\/|\;|\'|\`|\-|\=|\\\|\|/";    
    if (!preg_match($str,$C_url)){  
        return false;  
    }else{  
    return true;  
    }  }
//用户登录
	function login()
	{
	$b_name = isset($_POST['user_name']) ? trim($_POST['user_name']) : '';
	$b_pass = isset($_POST['user_pwd']) ? trim($_POST['user_pwd']) : '';
	$sql = 'select * from yycms_user where b_user = "'.$b_name.'" and b_pass = "'.md5($b_pass).'"';
	$result = mysql_query($sql);
	if(!! $row = mysql_fetch_array($result)){
	setcookie('user_name',$row['b_user'],time()+3600*24,'/');
	return json_encode(array('code' => '200', 'msg' => '登陆成功'));
	}else{
	return json_encode(array('code' => '400', 'msg' => '登陆失败-账号或密码错误'));
	}
	}
//用户注册
function reg()
{
$b_name = isset($_POST['user_name']) ? trim($_POST['user_name']) : '';
$b_pass = md5(trim($_POST['user_pwd']));
if(CheckUrl($b_name)){  
return json_encode(array('code' => '400', 'msg' => '用户名不能有特殊符号'));
}
//检测用户名是否存在
$query = mysql_query("select b_id from yycms_user where b_user='$b_name'");
if(mysql_fetch_array($query)){
return json_encode(array('code' => '400', 'msg' => '用户名存在'));
}
//推广者获得奖励
if ($_POST['tg']>='1'){
$resulttg = mysql_query('select * from yycms_shoufei');
$rowtj = mysql_fetch_array($resulttg);
$resultcx = mysql_query('select * from yycms_user where b_id="'.$_POST['tg'].'"');
$rowcx = mysql_fetch_array($resultcx);
$hqjf=$rowcx['b_jf']+$rowtj['sf_zc'];
$sql = 'update yycms_user set b_jf = '.$hqjf.' where b_id="'.$_POST['tg'].'"';
mysql_query($sql);
}
$yuming = $_SERVER['HTTP_HOST'];
$sql_jc = mysql_query("select * from yycms_pintai where a_url='$yuming'");
$row_jc   = mysql_fetch_array($sql_jc);
$hxlpintai_id = $row_jc['id'];
$data['b_pingtai'] = $hxlpintai_id;
$data['b_user'] = $b_name;
$data['b_pass'] =$b_pass;
$data['b_tg'] =$_POST['tg'];
$data['b_hy'] ='1';
$data['b_start'] =date('Y-m-d h:i:s', time());
$data['b_type'] =date('Y-m-d h:i:s', time()+ 86400*1);
$str = arrtoinsert($data);
$sqll = 'insert into yycms_user ('.$str[0].') values ('.$str[1].')';
if (mysql_query($sqll)) {
return json_encode(array('code' => '200', 'msg' => '注册成功'));
}
}
//修改密码
	function xgpwd()
	{
		return ;
	}
//查询用户的基本信息
	function cxname()
	{
		return ;
	}
//Home页面退出
function tuichu()
{
setcookie('user_name','',time()-3600*24,'/');
return json_encode(array('code' => 200, 'msg' => '账号退出成功'));
}
//升级会员
function hysj()
{
$resultcx = mysql_query('select * from yycms_user where b_user="'.$_POST['zh'].'"');
$rowcx = mysql_fetch_array($resultcx);
$hqjf=$rowcx['b_jf'];
$type=$rowcx['b_type'];
if($hqjf+1 <= $_POST['tcjf']){
return json_encode(array('code' => 400, 'msg' => '积分不足'));
}
//判定时间是否到期
if($type < date('Y-m-d h:i:s', time())){
$b_type = time() + 86400*$_POST['tcts'];//到期增加天数
}
else{
$b_type = strtotime($type) + 86400*$_POST['tcts'];//没到期增加天数
}
//更新数据
$_data['b_hy'] ='2';
$_data['b_jf'] =$hqjf-$_POST['tcjf'];
$_data['b_type'] =date('Y-m-d h:i:s',$b_type);
$sql = 'update yycms_user set '.arrtoupdate($_data).' where b_user="'.$_POST['zh'].'"';	
mysql_query($sql);
return json_encode(array('code' => 200, 'msg' => '升级成功'));
}
//留言提交
	function lytj()
	{
	session_start();
	if ($_SESSION['verifycode'] != $_POST['verifycode']) {
	return json_encode(array('code' => 400, 'msg' => '验证码错误'));
	}
   if(preg_match("/[ ',:;*~`!@#$%^&+=)(<>{}]|\]|\[|\/|\\\|\"|\|/",$_POST['gbook_content'])){
	return json_encode(array('code' => 400, 'msg' => '禁止使用特殊符号'));
    }
    $data['ly_name'] = $_POST['name'];
	$data['ly_nr'] = $_POST['gbook_content'];
	$data['ly_time'] =date('Y-m-d h:i:s');	
	$str = arrtoinsert($data);
	$sql = 'insert into yycms_ly ('.$str[0].') values ('.$str[1].')';
	if(mysql_query($sql)){
	return json_encode(array('code' => 200, 'msg' => '留言成功'));
    }else{
	return json_encode(array('code' => 400, 'msg' => '留言失败'));
	}
	}
//收藏影片
	function scyp()
	{
	$data['sc_user'] = $_POST['sc_user'];
    $data['sc_name'] = $_POST['sc_name'];
	$data['sc_url'] = $_POST['sc_url'];
	$data['sc_time'] =date('Y-m-d h:i:s');	
	$query = mysql_query('select * from yycms_sc where sc_name="'.$_POST['sc_name'].'"');
    if(mysql_fetch_array($query)){
    return json_encode(array('code' => '400', 'msg' => '请勿重复收藏'));
    }
	$str = arrtoinsert($data);
	$sql = 'insert into yycms_sc ('.$str[0].') values ('.$str[1].')';
	if(mysql_query($sql)){
	return json_encode(array('code' => 200, 'msg' => '影片'.$_POST['sc_name'].'收藏成功'));
    }else{
	return json_encode(array('code' => 400, 'msg' => '收藏失败'));
	}
	}
//删除影片
function scds()
{
$sql = 'delete from yycms_sc where sc_id in (' . $_POST['ypid'] . ')';
mysql_query($sql);
return json_encode(array('code' => '200', 'msg' => '删除成功'));
}
$a=$_POST['yycms'];
switch ($a){
    case "login": // 用户登陆
        echo login();
        break;
	case "reg": // 用户注册
        echo reg();
        break;
	case "tuichu": // 用户退出
        echo tuichu();
        break;	
	case "hysj": // 会员升级
        echo hysj();
        break;
	case "lytj": // 网站留言
        echo lytj();
        break;
	case "scyp": // 网站留言
        echo scyp();
        break;
	case "scds": // 删除影片
        echo scds();
        break;
	   default:
        echo bc();
}		
?>