<?php
$urllist='https://www.360kan.com/'.$_GET['play'];
mkdir('./cache'); 
mkdir('./cache/cnxh');
if($yycms_a_hckg == '1'){
$gxpd=time()-filemtime('./cache/cnxh/'.md5($urllist));
if($gxpd>$yycms_a_hcsj*60*60){
$info=gett($urllist);
file_put_contents('./cache/cnxh/'.md5($urllist),gzdeflate($info));
}
$like=gzinflate(file_get_contents('./cache/cnxh/'.md5($urllist)));
}else{
$like=gett($urllist);
}
$likezz="#<li  title='(.*?)' class='w-newfigure w-newfigure-(.*?)'><a href='(.*?)'#"; 
$likeimg="#<li  title='(.*?)' class='w-newfigure w-newfigure-(.*?)'><a href='(.*?)'  class='js-link'><div class='w-newfigure-imglink g-playicon js-playicon'> <img src='(.*?)' data-src='(.*?)' alt='(.*?)'  />#"; 
preg_match_all($likezz, $like,$likearr); 
preg_match_all($likeimg, $like,$likearr1); 
$likename=$likearr1[1]; 
$likeurl=$likearr1[3]; 
$likeimg=$likearr1[5]; 
if(count($likename) == 0){
  $likedm1="#<li class='g-clear'([\s\S]*?)</li>#"; 
  preg_match_all($likedm1, $like,$likedmwy1); 
  $likedm2="#<img src=\"(.*?)\" data-src='(.*?)'>#"; 
  $likedm3="#<p class='title'><a href='/(.*?)' data-index=(.*?)>(.*?)</a></p>#"; 
  preg_match_all($likedm2, $like,$likedmwy2); 
  preg_match_all($likedm3, $like,$likedmwy3);
  $likename=$likedmwy3[3]; 
  $likeurl=$likedmwy3[1]; 
  $likeimg=$likedmwy2[2]; 
}
$i=0;
foreach ($likename as $ks=>$vs){
if ($i<12){
$host1=$likeurl[$ks]; 
echo '<li class="col-lg- col-md-6 col-sm-4 col-xs-3"> 
          <div class="myui-vodlist__box"> 
           <a class="myui-vodlist__thumb lazyload" href="/vod/'.$host1.'" title="'.$vs.'" data-original="'.$likeimg[$ks].'"> <span class="play hidden-xs"></span> <span class="pic-tag pic-tag-top" style="background-color: #5bb7fe;">  </span> <span class="pic-text text-right"> </span> </a> 
           <div class="myui-vodlist__detail"> 
            <h4 class="title text-overflow"><a href="/vod/'.$host1.'" title="'.$vs.'">'.$vs.'</a></h4> 
           </div> 
          </div>
		  </li>';		  
$i ++;}
}?>