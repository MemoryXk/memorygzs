<?php
include('sava/inc.php');
include('sava/shoufei.php');
$id=$_GET['id'];
$zy=$_GET['zd'];
switch($zy){
    case 'zd1';
	     $zd=$yycmszyjx[0].'?vodids=';
         break;
    case 'zd2';
     	 $zd=$yycmszyjx[1].'?vodids=';
         break;
    case 'zd3';
    	 $zd=$yycmszyjx[2].'?vodids=';
         break;
         default ;
         break;
}
$data=json_decode(qwget($zd.$id),true);
$suArr1 = explode("$$$",$data['data'][0]['vod_url']);
				foreach($suArr1 as $a=>$b){  
				    $v = explode("\n",$b);
				    $d[] =$v; 
				}
				foreach($d as $k=>$v){    
				    foreach ($v as $k=>$cc){
				         $u = explode("$",$cc);
						if(strpos($u[1] ,'.m3u8')){
                 		$urls= $u[1];
						$dz.= $u[1];
                 		$title= $u[0];
                        $kk=$k+1;
						$url.='<li class="col-md-3 col-sm-5 col-xs-4 active"><a href="'.str_replace("https","http",$urls).'" class="btn1 btn btn-min btn-gray" target="ajax" data-clipboard-text="" id="'.$kk.'" p_name="'.$title.'">'.$title.'</a></li>';
						}		
					}
				}		
$suArr2= explode(".m3u8",$dz);
$qqsp=explode(',',$yycms_a_qqsp);
for($i=0;$i<count($qqsp);$i++)
{
if($title==$qqsp[$i]){
//提示错误值
alert_href('由于侵权,视频已经下架,谢谢!','/index.html');	
     }	
}
include('templets/'.$yycms_a_mb.'/qwplay.php');
?>