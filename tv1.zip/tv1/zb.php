<?php
include('sava/inc.php');
include('sava/zby.php');
include('templets/'.$yycms_a_mb.'/zb.php');
?>