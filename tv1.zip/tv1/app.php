<?php
include('sava/inc.php');
include('templets/'.$yycms_a_mb.'/app.php');
?>