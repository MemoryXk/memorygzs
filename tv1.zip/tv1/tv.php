<?php
include('sava/inc.php');
if ($_GET['year']==''||$_GET['year']=='all'){
$nian='';
}else{
$nian=$_GET['year'];	
}
if ($_GET['act']==''||$_GET['act']=='all'){
$minx='';
}else{
$minx=$_GET['act'];	
}
include('templets/'.$yycms_a_mb.'/tv.php');
?>